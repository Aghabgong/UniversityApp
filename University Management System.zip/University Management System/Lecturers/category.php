<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

if (isset($_GET['del'])) {
    $del_id = $_GET['del'];
    $del_query = "DELETE FROM category WHERE cat_id = '$del_id'";
    $del_run = mysqli_query($con, $del_query);
    if ($del_run) {
        echo "<script>alert('Category Deleted Successfully')</script>";
        echo "<script>window.open('categories.php','_self')</script>";
        exit; // Make sure to exit after redirection
    }
}
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="../images/logo.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-primary">View All Categories</h2>
                    <div align="right">

                        <hr>
                    </div>
                    <table class="table table-border" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Sr No</th>
                                <th>Category Name</th>
                               
                           
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $category_query = "SELECT * FROM category ORDER BY cat_id desc";
                            $category_result = mysqli_query($con, $category_query);
                            if ($category_result) {
                                $i = 0;
                                while ($category_row = mysqli_fetch_assoc($category_result)) {
                                    $cat_id = $category_row['cat_id'];
                                    $cat_name = $category_row['cat_name'];
                                    

                                    $i++;
                                    // Display the category details in table rows
                                    ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo ucfirst($cat_name); ?></td>
                                       
                                      
                                       
                                    </tr>
                            <?php
                                }
                            } else {
                                // Error fetching categories
                                echo "Error fetching categories: " . mysqli_error($con);
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px">Export to Excel</button>
        </div>
    </div>
</div>
<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>
</body>
</html>
<script>
    $(document).ready(function() {
        $('#table2excel').DataTable();
    });
</script>
<script>
    $("#btn").click(function() {
        $("#table2excel").table2excel({
            name: "Worksheet name",
            filename: "myExcelFile.xls"
        });
    });
</script>
