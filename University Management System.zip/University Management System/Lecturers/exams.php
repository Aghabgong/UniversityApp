<?php
// Start session and include necessary files
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Fetch all exams from the database
$examsQuery = "SELECT * FROM exams";
$examsResult = mysqli_query($con, $examsQuery);
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-primary p-2 rounded">Registered Exams</h2>
                    <hr class="bg-primary">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Exam Name</th>
                                    <th>Date</th>
                                    <th>Course</th>
                                    <th>Department</th>
                                    <th>Total Marks</th>
                                    <th>Exam Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Check if there are any exams in the database
                                if(mysqli_num_rows($examsResult) > 0) {
                                    // Output data of each exam
                                    while($row = mysqli_fetch_assoc($examsResult)) {
                                        echo "<tr>";
                                        echo "<td>" . $row["examName"] . "</td>";
                                        echo "<td>" . $row["exam_date"] . "</td>";
                                        echo "<td>" . $row["course_name"] . "</td>";
                                        echo "<td>" . $row["cat_name"] . "</td>";
                                        echo "<td>" . $row["totalMarks"] . "</td>";

                                        // Display exam time
                                        if(isset($row["time"])) {
                                            echo "<td>" . $row["time"] . " minutes</td>";
                                        } else {
                                            echo "<td>N/A</td>"; // If "time" key is not present
                                        }
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='6'>No exams found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

</body>
</html>
