<nav class="navbar navbar-expand-lg navbar-light bg-primary p-0">
  <div class="container-fluid">
    <a class="navbar-brand text-light" href="index.php">KEBHIPS LECTURERS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active text-light" href="index.php"><i class="fa fa-home"></i>Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="gallery.php"><i class="fa fa-camera"></i>View Gallery</a>
        </li>
        <li class="nav-item dropdown dropdown-right">
          <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-book"></i>Create Masters
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="">Upload Exam Questions</a>
            <a class="dropdown-item" href="">Upload Notes</a>
            <a class="dropdown-item" href="">View</a>
            <a class="dropdown-item" href="teaching_timetable.php">Time Tables</a>
          </div>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <?php
        if(isset($_SESSION['lec_name'])) {
          // If logged in as a lecturer, show logout button
          echo '<form method="post" action="logout.php">
                  <button class="btn btn-link text-light" type="submit" name="logout"><i class="fa fa-sign-out"></i>Logout</button>
                </form>';
        } else {
          // If not logged in as a lecturer, show login button
          echo '<li class="nav-item dropdown dropdown-left">
                  <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-cog"></i>
                  </a>
                  <div class="dropdown-menu dropdown-left" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="Lecturers/login.php">Lecturer Login</a>
                    <!-- Add other login links as needed -->
                  </div>
                </li>';
        }
        ?>
      </ul>
    </div>
  </div>
</nav>
