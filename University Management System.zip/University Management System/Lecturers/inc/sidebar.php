<?php

$student = "SELECT * FROM student";
$student_run = mysqli_query($con, $student);
$row_student = mysqli_num_rows($student_run);

$courses = "SELECT * FROM courses";
$courses_run = mysqli_query($con, $courses);
$row_courses = mysqli_num_rows($courses_run);

$register = "SELECT * FROM register";
$register_run = mysqli_query($con, $register);
$row_register = mysqli_num_rows($register_run);

$category = "SELECT * FROM category";
$category_run = mysqli_query($con, $category);
$row_category = mysqli_num_rows($category_run);

$exams = "SELECT * FROM exams";
$exams_run = mysqli_query($con, $exams);
$row_exams = mysqli_num_rows($exams_run);

$attendance = "SELECT * FROM attendance";
$attendance_run = mysqli_query($con, $attendance);
$row_attendance = mysqli_num_rows($attendance_run);

?>

<div class="list-group">
    <a href="index.php" class="list-group-item list-group-item-action active"><i class="fa fa-tachometer"></i>Dashbord</a>
    
    <a href="student.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-user"></i>Student<button type="button" class="btn btn-primary pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_student"; ?></span>
        </button>
    </a>
   
   
    
    <a href="courses.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-life-ring"></i>Courses<button type="button" class="btn btn-primary pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_courses"; ?></span>
        </button>
    </a>
   
    
    <a href="category.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-sort"></i>Departments<button type="button" class="btn btn-primary pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_category"; ?></span>
        </button>
    </a>
     
    
    <a href="exams.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-question"></i>Exams<button type="button" class="btn btn-primary pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_exams"; ?></span>
        </button>
    </a>
    
    <a href="presence.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-photo"></i>Attendance<button type="button" class="btn btn-primary pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_attendance"; ?></span>
        </button>
    </a>
   
</div>
