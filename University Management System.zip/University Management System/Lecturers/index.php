<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');
?>

<div class="row mt-2">
    <div class="col-md-12">
        <?php include('inc/navbar.php') ?>
    </div>
</div>

<div class="row mt-1">
    <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
    <div class="col-md-9">
        <!-- Student Details Section -->
        <div class="row">
            <div class="col-md-12">
                <img src="../admin/images/logo.jpg" class="img-fluid" width="70px" /><hr>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center text-white bg-primary">Stat overview of KEBHIPS</h2>
            </div>
            <div class="col-md-4">
                <div class="card text-primary border-primary">
                    <div class="card-header bg-primary text-white">Students</div>
                    <div class="card-body">
                        <table class='table table-bordered table-condensed'>
                            <thead>
                                <tr>
                                    <th>Departments</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $categoryQuery = "SELECT DISTINCT cat_name FROM student";
                                $categoryResult = mysqli_query($con, $categoryQuery);
                                
                                while ($categoryRow = mysqli_fetch_assoc($categoryResult)) {
                                    $categoryName = $categoryRow['cat_name'];
                                    
                                    $studentQuery = "SELECT COUNT(*) AS total_students FROM student WHERE cat_name = '$categoryName'";
                                    $studentResult = mysqli_query($con, $studentQuery);
                                    $rowCount = mysqli_fetch_assoc($studentResult)['total_students'];
                                ?>
                                <tr>
                                    <td><?php echo $categoryName; ?></td>
                                    <td><?php echo $rowCount; ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-8 mt-2">
                <!-- Student Marks Allocation Table -->
                <h2 class="text-center text-white bg-secondary">Marks Allocation</h2><hr>
                <table class="table table-bordered table-condensed" id="table2excel">
                    <thead class="bg-dark text-white">
                        <tr>
                            
                            <th>Course</th>
                           
                            <th>Obtained CA Marks</th> 
                            <th>Exam Marks</th>
                            <th>Obtained Exam Marks</th>
                            <th>Total Marks</th>
                            <th>Obtained Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if(isset($_GET['id'])) {
                            $user_id = $_GET['id'];
                            $result = "SELECT * FROM result WHERE student_id = '$user_id'";
                            $run_result = mysqli_query($con,$result);
                            
                            while($row_result = mysqli_fetch_assoc($run_result)){
                               
                                $course_name = $row_result['course_name'];
                              
                                $Obtained_ca = $row_result['Obtained_ca'];
                                $exam_marks = $row_result['exam_marks'];
                                $obtainedMarks = $row_result['obtainedMarks'];
                                $gen_total = $row_result['gen_total'];
                                $total_ob_marks = $row_result['total_ob_marks'];
                        ?>
                        <tr>
                            
                            <td><?php echo $course_name; ?></td>
                           
                            <td><?php echo $Obtained_ca; ?></td>
                            <td><?php echo $exam_marks; ?></td>
                            <td><?php echo $obtainedMarks; ?></td>
                            <td><?php echo $gen_total; ?></td>
                            <td><?php echo $total_ob_marks; ?></td>
                        </tr>
                        <?php };?>
                    </tbody>
                </table><hr>
            </div>
        </div>

        <!-- Attendance Details Section -->
        
<div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>

</body>
</html>

<script>
    $(document).ready(function(){
        $('#table2excel').DataTable();
    });
    
</script>
<script>
    $(document).ready(function(){
        $('#newtable2excel').DataTable();
    });
    
</script>
<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
        
<?php 

                }
?>