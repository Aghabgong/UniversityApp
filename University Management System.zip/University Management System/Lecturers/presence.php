<?php
ob_start();
session_start();



require_once('inc/top.php');
require_once('inc/db.php');

// If 'id' parameter is set in the URL
if(isset($_GET['id'])){
    // If 'id' parameter is set, redirect to the presence check page directly
    $id = $_GET['id'];
    header('location: viewCourses.php?id='.$id);
    exit(); // Add exit to stop further execution
}

// If 'category_filter' parameter is set, filter students by category
$category_filter = '';
if(isset($_GET['category_filter']) && !empty($_GET['category_filter'])){
    $category_filter = $_GET['category_filter'];
    $category_filter_condition = "WHERE cat_name = '$category_filter'";
} else {
    $category_filter_condition = ''; // Show all students if category filter is not set
}

// Fetch all students from the database based on the search query or category filter
$students_query = "SELECT * FROM student $category_filter_condition";
$students_result = mysqli_query($con, $students_query);
?>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="../admin/images/logo.jpg" class="img-fluid" width="70px"/><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <a href="index.php" class="btn btn-success">Back To Home</a><hr>
                    <h2 class="text-center text-white bg-primary">Students Attendance Details</h2><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mb-3">
                    <form method="GET" action="">
                        <div class="input-group">
                            <select class="form-control" name="category_filter">
                                <option value="">All Categories</option>
                                <?php
                                // Fetch distinct categories from the database
                                $category_query = "SELECT DISTINCT cat_name FROM student";
                                $category_result = mysqli_query($con, $category_query);
                                while($category_row = mysqli_fetch_assoc($category_result)){
                                    $category = $category_row['cat_name'];
                                    $selected = ($category == $category_filter) ? 'selected' : '';
                                    echo "<option value='$category' $selected>$category</option>";
                                }
                                ?>
                            </select>
                            <button class="btn btn-primary" type="submit">Filter</button>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-bordered">
                        <thead class="text-center bg-dark text-white">
                            <tr>
                                <th>Student Name</th>
                                <th>Attendance Date</th>
                                <th>Attendance Status</th>
                               
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fetch students based on search query or category filter
                            $runStudent = mysqli_query($con, $students_query);

                            while($rowStudent = mysqli_fetch_assoc($runStudent)){
                                $student_id = $rowStudent['id'];
                                $student_name = $rowStudent['name'];
                                $student_attendance_query = "SELECT * FROM attendance WHERE student_id = '$student_id' ORDER BY attdid DESC";
                                $runStudentAttendance = mysqli_query($con, $student_attendance_query);
                                ?>
                                <tr>
                                    <td><?php echo $student_name; ?></td>
                                    <td>
                                        <?php
                                        while($rowStudentAttendance = mysqli_fetch_assoc($runStudentAttendance)){
                                            $date = date('y-m-d', strtotime($rowStudentAttendance['date']));
                                            echo $date . '<br>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        mysqli_data_seek($runStudentAttendance, 0); // Reset pointer
                                        while($rowStudentAttendance = mysqli_fetch_assoc($runStudentAttendance)){
                                            $attendance = $rowStudentAttendance['attendance'];
                                            echo '<span class="' . (($attendance == "Present") ? "text-primary" : "text-danger") . '">' . $attendance . '</span><br>';
                                        }
                                        ?>
                                    </td>
                                    
                                </tr>
                            <?php };?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
    </div>
</div>
