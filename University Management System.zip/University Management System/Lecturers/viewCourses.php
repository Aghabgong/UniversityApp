<?php
ob_start();
session_start();

 


require_once('inc/top.php');
require_once('inc/db.php');

// Check if 'id' parameter is set and not empty
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = mysqli_real_escape_string($con, $_GET['id']); // Sanitize input
} else {
    // Handle case where 'id' parameter is not provided
    // For example, you could display an error message or redirect the user
    echo "Error: Course ID is not provided.";
    exit(); // Stop further execution
}

if (isset($_POST['checkboxes'])) {
    foreach ($_POST['checkboxes'] as $user_id) {
        $bulk_option = mysqli_real_escape_string($con, $_POST['bulk-options']); // Sanitize input

        // Prepare statement to prevent SQL injection
        $insert = mysqli_prepare($con, "INSERT INTO attendance (student_id, attendance, date) VALUES (?, ?, NOW())");
        mysqli_stmt_bind_param($insert, 'is', $user_id, $bulk_option);
        mysqli_stmt_execute($insert);
    }
}

?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-primary">Students by Batch</h2>
                    <!-- Your form for bulk options here -->
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                        <div class="row">
                            <div class="col-xs-4">
                                <div class="form-group">
                                    <select class="form-control" name="bulk-options">
                                        <option value="">Please Select</option>
                                        <option value="Present">Present</option>
                                        <option value="Absent">Absent</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-8 mb-2">
                                <input type="submit" class="btn btn-warning" value="Apply" onclick="return_confirm('Please Confirm');" />
                            </div>
                        </div>
                    </form>
                    <table class="table table-border" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th><input type="checkbox" id="selectallboxes"> </th>
                                <th scope="col">Sr No</th>
                                <th scope="col">Student Name</th>
                                <th scope="col">Gender</th>
                                <th scope="col">Class</th>
                                <th scope="col">Batch</th>
                                <th scope="col">Image</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Query to select students belonging to the specified batch
                            $student_query = "SELECT * FROM student WHERE batch = '$id'";

                            $result = mysqli_query($con, $student_query);
                            $ia = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
    $student_id = $row['id']; // Renamed to avoid overwriting $id
    $name = $row['name'];
    $class = $row['class'];
    $student_batch = $row['batch']; // Renamed to avoid overwriting $batch
    $image = $row['image'];
    $gender = $row['gender'];
    // $mobile = $row['mobile'];
    // $subject = $row['subject'];
    // $address = $row['address'];
    $ia++;
    // Fetch course name
    $course_query = "SELECT course_name FROM courses WHERE course_id = '$student_batch'";
    $course_result = mysqli_query($con, $course_query);
    $course_row = mysqli_fetch_assoc($course_result);
    $course_name = $course_row['course_name'];
                            ?>
                                <tr>
                                    <td><input type="checkbox" class="checkboxes" name="checkboxes[]" value="<?php echo $id; ?>"> </td>
                                    <td><?php echo $ia ?></td>
                                    <td><a href="presence.php?id=<?php echo $id; ?>"><?php echo ucfirst($name); ?></a></td>
                                    <td><?php echo $gender; ?></td>
                                    <td><?php echo $class; ?></td>
                                    <td><?php echo $course_name; ?></td>
                                    <td><img class="img-fluid" src="../images/student/<?php echo $image; ?>" width="50px" /></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <!-- Export to Excel button -->
                <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px">Export to Excel</button>
            </div>
        </div>
    </div>
</div>
<div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>

</body>

</html>
<script>
    $(document).ready(function() {
        $('#table2excel').DataTable();
    });

    $("#btn").click(function() {
        $("#table2excel").table2excel({
            name: "Worksheet name",
            filename: "myExcelFile.xls"
        });
    });

    $(document).ready(function() {
        $('#selectallboxes').click(function(event) {
            if (this.checked) {
                $('.checkboxes').each(function() {
                    this.checked = true;
                });
            } else
