<?php
include('inc/top.php');


?>

<div class="container-fluid p-0">
    <div class="row">
        <div class="col-lg-12 mt-2">
            <?php include('inc/navbar.php'); ?>
            
        </div>
    </div>
    
    <div class="row mt-2" >
        <div class="col-md-9">
           <div class="card">
                <div class="card-head bg-success text-white">
                About G.H.A.C
               </div>
               <div class="card-body text-justify">
                <p class="card-text">
                   We know you are in search of the best Academy for your Children..........
                   </p>
                    <p class="card-text">
                   We know you are in search of the best Academy for your Children..........
                   </p>
                    <p class="card-text">
                   We know you are in search of the best Academy for your Children..........<br>
                        D.H.A.C Talent search exams will be held on the ________
                   </p>
                   <a href="gallery.php" class="btn btn-secondary">View Gallery</a>
               </div>
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h3 class="card-title text-center">Director</h3>
                </div>
            </div>
            <img src="images/logo.jpg" class="img-fluid"/>
        </div>
    </div>
    
    <div class="container-fluid">
        <div class="row bg-dark mt-2">
        <?php include('inc/footer.php'); ?>
    </div>
    </div>
</div>

</body>
</html>