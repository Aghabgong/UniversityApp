<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

// Check if the form is submitted
if (isset($_POST['submit'])) {
    // Sanitize user input
    $depName = sanitize_input($_POST['depName']);
    $depfees = sanitize_input($_POST['depfees']);
    $depStart = sanitize_input($_POST['depStart']);

    // Check if the category already exists
    $check_query = "SELECT * FROM category WHERE cat_name = '$depName' AND cat_fee = '$depfees' AND cat_start = '$depStart'";
    $check_result = mysqli_query($con, $check_query);
    if (mysqli_num_rows($check_result) > 0) {
        // Category already exists, show error message
        echo "<script>alert('Category already exists')</script>";
    } else {
        // Insert category into the database
        $insert_category = "INSERT INTO category (cat_name, cat_fee, cat_start) 
                            VALUES ('$depName', '$depfees', '$depStart')"; // Added missing quote before $depfees

        $insert_result = mysqli_query($con, $insert_category);
        if ($insert_result) {
            // Successful insertion, get the inserted category ID
            $category_id = mysqli_insert_id($con);

            // Fetch the inserted category details to display to the user (optional)
            $category_query = "SELECT * FROM category WHERE cat_id = '$category_id'";
            $category_result = mysqli_query($con, $category_query);
            $category_row = mysqli_fetch_assoc($category_result);

            // Display success message and category details
            echo "<script>alert('Category Successfully added')</script>";
           
            echo "<script>window.open('addCourse.php','_self')</script>";
            exit(); // Terminate script after redirection
        } else {
            // Unsuccessful insertion
            echo "Error: " . mysqli_error($con);
        }
    }
}

function sanitize_input($data) {
    $data = trim($data); // Remove whitespace from the beginning and end of string
    $data = stripslashes($data); // Remove backslashes (\)
    $data = htmlspecialchars($data); // Convert special characters to HTML entities
    return $data;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
</head>
<body>
    <div class="container-fluid">
        <div class="row mt-2">
            <div class="col-md-12">
                <?php include('inc/navbar.php') ?>
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-12">
                        <img src="images/logo1.jpg" class="img-fluid" width="70px" /><hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-center text-white bg-success">Add Class</h2><hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label text-secondary">
                                    Class Name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" placeholder="Enter Department name" name="depName" required/>
                                </div>
                            </div>
                            
                             
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label text-secondary">
                                  Class Fee
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" placeholder="Enter Department Fees" name="depfees" required/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label text-secondary">
                                    Start Date
                                </label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" placeholder="Enter Start Date" name="depStart" required/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-10 offset-sm-2">
                                    <button class="btn btn-outline-success btn-block mt-2" type="submit" name="submit">Add Class</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>
    </div>
</body>
</html>
