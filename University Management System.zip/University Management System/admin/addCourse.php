<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

if (isset($_POST['submit'])) {
    $courseName = sanitize_input($_POST['courseName']);

    // Check if the course already exists
    $check_course_query = "SELECT * FROM courses WHERE course_name = '$courseName'";
    $check_course_result = mysqli_query($con, $check_course_query);
    if (mysqli_num_rows($check_course_result) > 0) {
        // Course already exists
        echo "<script>alert('Course already exists')</script>";
    } else {
        // Course does not exist, proceed with insertion
        $insert_course = "INSERT INTO courses (course_name) 
                          VALUES ('$courseName')";

        $insert_result = mysqli_query($con, $insert_course);
        if ($insert_result) {
            // Successful insertion
            echo "<script>alert('Course Successfully added')</script>";
            echo "<script>window.open('Courses.php','_self')</script>";
            exit(); // Terminate script after redirection
        } else {
            // Unsuccessful insertion
            echo "Error: " . mysqli_error($con);
        }
    }
}

function sanitize_input($data) {
    $data = trim($data); // Remove whitespace from the beginning and end of string
    $data = stripslashes($data); // Remove backslashes (\)
    $data = htmlspecialchars($data); // Convert special characters to HTML entities
    return $data;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Courses</title>
</head>
<body>
    <div class="container-fluid">
        <div class="row mt-2">
            <div class="col-md-12">
                <?php include('inc/navbar.php') ?>
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-12">
                        <img src="images/logo1.jpg" class="img-fluid" width="70px" /><hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h2 class="text-center text-white bg-success">Add Subject</h2><hr>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
                            <div class="form-group row">
                                <label class="col-sm-2 col-form-label text-secondary">
                                    Subject name
                                </label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" placeholder="Enter course name" name="courseName" required/>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-sm-10 offset-sm-2">
                                    <button class="btn btn-outline-success btn-block mt-2" type="submit" name="submit">Add Subject</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>
    </div>
</body>
</html>
