<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if(isset($_POST['submit'])) {
    $Imagetitle = $_POST['Imagetitle'];
    $U_image = $_FILES['U_image']['name'];
    $image_tmp = $_FILES['U_image']['tmp_name'];
    $U_image = 'GalleryImg' . date('Y-m-d-H-i-s') . '_' . uniqid() . '.jpg';

    // Check for file upload errors
    $upload_error = $_FILES['U_image']['error'];
    if($upload_error !== UPLOAD_ERR_OK) {
        echo "<script>alert('Failed to upload image. Error code: $upload_error')</script>";
        exit; // Stop script execution if file upload fails
    }

    if(move_uploaded_file($image_tmp, "../images/gallery/$U_image")) {
        // Output debugging information
        echo "Imagetitle: $Imagetitle<br>";
        echo "U_image: $U_image<br>";

        $insert_gallery = "INSERT INTO galerry (gallery_title, gallery_img) VALUES ('$Imagetitle', '$U_image')";
        // Output the SQL query for debugging
        echo "SQL Query: $insert_gallery<br>";

        $insert_pro = mysqli_query($con, $insert_gallery);

        if($insert_pro) {
            echo "<script>alert('Image Successfully added')</script>";
            echo "<script>window.open('gallery.php','_self')</script>";
        } else {
            // Output MySQLi error if query fails
            echo "MySQLi Error: " . mysqli_error($con);
            echo "<script>alert('Failed to add image to database. Please try again.')</script>";
        }
    } else {
        echo "<script>alert('Failed to upload image.')</script>";
    }
}
?>


    <dIv class="container-fluid">
        <div class="row mt-2">
            <div class="col-md-12">
                <?php include ('inc/navbar.php')?>
                
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
             <div class="col-md-9">
                <div class="row">
                 <div class="col-md-12">
                        <img src="images/logo1.jpg" class="img-fluid" width="70px"/><hr>
                    </div>
                 </div>
                 <div class="row">
                 <div class="col-md-12">
                     <h2 class="text-center text-white bg-success">Add Gallery Images</h2><hr>
                    </div>
                     
                     <form action="" method="post" enctype="multipart/form-data" >
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-secondary">
                                Image Title
                            </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter image title" name="Imagetitle" required/>
                            </div>
                         </div>
                         <div class="form-group mt-2 row">
                            <label class="col-sm-2 col-form-label text-secondary">
                                Product Image
                            </label>
                            <div class="col-sm-10">
                                <input type="file" class="form-control file btn btn-success" name="U_image" required/>
                                <div class="form-group">
                                    <div class="offset-sm-2 col-sm-10">
                                <button class="btn btn-outline-success btn-block mt-2" type="submit" name="submit">Add Image</button>
                                        </div>
                                    </div>
                            </div>
                             
                         </div>
                          
                     </form>
                     
                    </div>
            </div>
        </div>
</dIv>
        
        <div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
    
</body>
</html>
