<?php
ob_start();
session_start();

// Function to sanitize input data
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

require_once('inc/top.php');
require_once('inc/db.php');

// Handle form submission
if (isset($_POST['submit'])) {
    // Sanitize input data
    $StudentName = sanitize_input($_POST['StudentName']);
    $StudentAddress = sanitize_input($_POST['StudentAddress']);
    $Category = sanitize_input($_POST['Category']);
    $gender = sanitize_input($_POST['gender']);
    $mobile = sanitize_input($_POST['mobile']);
    $email = sanitize_input($_POST['email']);
    $date = sanitize_input($_POST['date']);

    // Fetch category fee
    $get_category_fee = "SELECT cat_fee FROM category WHERE cat_id = $Category";
    $result = mysqli_query($con, $get_category_fee);
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $fee = $row['cat_fee'];

        // File upload handling
        $image_tmp = $_FILES['stdimage']['tmp_name'];
        $stdimage = 'advert' . date('Y-m-d-H-i-s') . '_' . uniqid() . '.jpg';
        $upload_directory = "../images/advert/";

        if (move_uploaded_file($image_tmp, $upload_directory . $stdimage)) {
            // Insert data into database
            $insert_student = "INSERT INTO student (name, address, cat_name, gender, mobile, email, fees, dob, image, date) 
            VALUES ('$StudentName','$StudentAddress',(SELECT cat_name FROM category WHERE cat_id = $Category),'$gender','$mobile','$email','$fee','$date','$stdimage',NOW())";

            $insert_pro = mysqli_query($con, $insert_student);
            if ($insert_pro) {
                // Successful insertion
                echo "<script>alert('Student Successfully added')</script>";
                echo "<script>window.open('student.php','_self')</script>";
                exit(); // Terminate script after redirection
            } else {
                // Unsuccessful insertion
                echo "Error: " . mysqli_error($con);
            }
        } else {
            // Error handling for file upload
            echo "Error uploading file.";
        }
    } else {
        // Error handling for fetching category fee
        echo "Error: Unable to fetch category fee.";
    }
}
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>

        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" /><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Add Student</h2><hr>
                </div>

                <form action="" method="post" enctype="multipart/form-data">
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Student name
                        </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="Enter student name" name="StudentName" required />
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Student Address
                        </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="Enter student Address" name="StudentAddress" required />
                        </div>
                    </div>

                   
    
   <div class="form-group row">
    <label class="col-sm-2 col-form-label text-secondary">
        Category
    </label>
    <div class="col-sm-10">
        <select class="form-control" name="Category" required>
            <option value="">Select Class</option>
            <?php
            $getCategories = "SELECT * FROM category";
            $run_categories = mysqli_query($con, $getCategories);
            if(mysqli_num_rows($run_categories) > 0) {
                while ($row_category = mysqli_fetch_assoc($run_categories)) {
                    $id = $row_category['cat_id'];
                    $category_name = $row_category['cat_name'];
            ?>
                    <option value="<?php echo $id; ?>"><?php echo $category_name; ?></option>
            <?php 
                }
            } 
            ?>
        </select>
        <?php if(mysqli_num_rows($run_categories) == 0) { ?>
            <input type="text" class="form-control" placeholder="No categories found" readonly />
        <?php } ?>
    </div>
</div>

                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Gender
                        </label>
                        <div class="col-sm-10">
                            <select class="form-control" name="gender" required>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Mobile
                        </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="Enter mobile" name="mobile" required />
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Email
                        </label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" placeholder="Enter email" name="email" required />
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Date Of Birth
                        </label>
                        <div class="col-sm-10">
                            <input type="date" class="form-control" name="date" required />
                        </div>
                    </div>

                    <div class="form-group mt-2 row">
                        <label class="col-sm-2 col-form-label text-secondary">
                            Student Image
                        </label>
                        <div class="col-sm-10">
                            <input type="file" class="form-control file btn btn-success" name="stdimage" required />
                            <div class="form-group">
                                <div class="offset-sm-2 col-sm-2">
                                    <button class="btn btn-outline-success btn-block mt-2" type="submit" name="submit">Add Student</button>
                                </div>
                            </div>
                        </div>

                    </div>

                </form>

            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>

</body>

</html>