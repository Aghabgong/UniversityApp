<?php
// Start session and include necessary files
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Fetch subjects from the database
$subjectQuery = "SELECT * FROM courses";
$subjectResult = mysqli_query($con, $subjectQuery);

// Fetch classes from the category table
$classQuery = "SELECT * FROM category";
$classResult = mysqli_query($con, $classQuery);

// Check if the form is submitted
if(isset($_POST['submit'])) {
    // Retrieve form data
    $exam_name = $_POST['exam_name'];
    $exam_date = $_POST['date'];
    $course = $_POST['course']; // Updated
    $category = $_POST['category']; // Updated
    $total_marks = $_POST['total_marks'];
    $exam_time_hours = $_POST['exam_time_hours'];
    $exam_time_minutes = $_POST['exam_time_minutes'];

    // Convert hours and minutes to total minutes
    $total_exam_time_minutes = ($exam_time_hours * 60) + $exam_time_minutes; // Correct calculation

    // Check if an exam with the same course and category already exists
    $duplicateQuery = "SELECT * FROM exams WHERE course_name = '$course' AND cat_name = '$category'";
    $duplicateResult = mysqli_query($con, $duplicateQuery);

    if(mysqli_num_rows($duplicateResult) > 0) {
        // Exam with the same course and category already exists
        echo "<script>alert('Exam with the same course and category already exists')</script>";
    } else {
        // SQL query to insert exam data into the database
        $insertQuery = "INSERT INTO exams (examName, exam_date, course_name, cat_name, totalMarks, timer) 
                        VALUES ('$exam_name', '$exam_date', '$course', '$category', '$total_marks', '$total_exam_time_minutes')";

        // Execute the query
        $result = mysqli_query($con, $insertQuery);

        // Check if the query was successful
        if($result) {
            // Exam inserted successfully
            echo "<script>alert('Exam added successfully')</script>";
        } else {
            // Error occurred while inserting the exam
            echo "Error: " . mysqli_error($con);
        }
    }
} ?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Add Exam</h2>
                    <hr>
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="exam_name">Exam Name:</label>
                            <input type="text" class="form-control" id="exam_name" name="exam_name" required>
                        </div>
                        <div class="form-group">
                            <label for="date">Date:</label>
                            <input type="date" class="form-control" id="date" name="date" required>
                        </div>
                        <div class="form-group">
                            <label for="course">Course:</label>
                            <select class="form-control" id="course" name="course" required> <!-- Updated -->
                                <option value="">Select Course</option>
                                <?php while($row = mysqli_fetch_assoc($subjectResult)) { ?>
                                    <option value="<?php echo $row['course_name']; ?>"><?php echo $row['course_name']; ?></option> <!-- Updated -->
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="class">Department:</label>
                            <select class="form-control" id="class" name="category" required> <!-- Updated -->
                                <option value="">Select Department</option>
                                <?php while($row = mysqli_fetch_assoc($classResult)) { ?>
                                    <option value="<?php echo $row['cat_name']; ?>"><?php echo $row['cat_name']; ?></option> <!-- Updated -->
                                <?php } ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="total_marks">Total Marks:</label>
                            <input type="number" class="form-control" id="total_marks" name="total_marks" required>
                        </div>
                        <div class="form-group">
                            <label for="exam_time_hours">Exam Time (Hours):</label>
                            <input type="number" class="form-control" id="exam_time_hours" name="exam_time_hours" min="0" required>
                        </div>
                        <div class="form-group">
                            <label for="exam_time_minutes">Exam Time (Minutes):</label>
                            <input type="number" class="form-control" id="exam_time_minutes" name="exam_time_minutes" min="0" required>
                        </div>
                        <button type="submit" name="submit" class="btn btn-success">Add Exam</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

</body>
</html>
