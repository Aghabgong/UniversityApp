<?php
// Start session and include necessary files
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Fetch categories from the database
$categoryQuery = "SELECT * FROM category"; // Assuming category table name is 'category'
$categoryResult = mysqli_query($con, $categoryQuery);
if (!$categoryResult) {
    die('Error fetching categories: ' . mysqli_error($con));
}

// Fetch courses from the database
$courseQuery = "SELECT * FROM courses"; // Assuming 'courses' is the table name
$courseResult = mysqli_query($con, $courseQuery);
if (!$courseResult) {
    die('Error fetching courses: ' . mysqli_error($con));
}

// Function to check if a teacher already exists
function teacherExists($con, $teacher_name) {
    $checkQuery = "SELECT teacherid FROM teachers WHERE teacher_name = ?";
    $stmt = mysqli_prepare($con, $checkQuery);
    mysqli_stmt_bind_param($stmt, "s", $teacher_name);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $count = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);
    return $count > 0;
}

// Function to insert a new teacher
function insertTeacher($con, $teacher_name) {
    $insertTeacherQuery = "INSERT INTO teachers (teacher_name) VALUES (?)";
    $stmt = mysqli_prepare($con, $insertTeacherQuery);
    mysqli_stmt_bind_param($stmt, "s", $teacher_name);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $result;
}

function insertTeacherAssignments($con, $teacher_id, $course_id, $cat_id, $days, $time_slot) {
    // Convert time slot to a consistent format (e.g., all lowercase)
    $time_slot_lower = strtolower($time_slot);

    $all_successful = true; // Flag to track if all assignments were successful

    foreach ($days as $day_of_week) {
        // Check if there is any other assignment for the same teacher on the same day and time slot
        $checkQuery = "SELECT * FROM teacher_assignments WHERE teacherid = ? AND day_of_week = ? AND LOWER(time_slot) = ?";
        $stmt_check = mysqli_prepare($con, $checkQuery);
        mysqli_stmt_bind_param($stmt_check, "iss", $teacher_id, $day_of_week, $time_slot_lower);
        mysqli_stmt_execute($stmt_check);
        mysqli_stmt_store_result($stmt_check);
        $count = mysqli_stmt_num_rows($stmt_check);
        mysqli_stmt_close($stmt_check);

        // If there is already an assignment for the same teacher, day, and time slot, set flag to false
        if ($count > 0) {
            $all_successful = false;
            continue; // Skip the current iteration and proceed to the next day
        }

        // Insert the assignment for the current day
        $insertAssignmentQuery = "INSERT INTO teacher_assignments (teacherid, course_id, cat_id, day_of_week, time_slot) VALUES (?, ?, ?, ?, ?)";
        $stmt_insert = mysqli_prepare($con, $insertAssignmentQuery);
        mysqli_stmt_bind_param($stmt_insert, "iiiss", $teacher_id, $course_id, $cat_id, $day_of_week, $time_slot);
        $result = mysqli_stmt_execute($stmt_insert);
        mysqli_stmt_close($stmt_insert);

        // If insertion failed for any day, set flag to false
        if (!$result) {
            $all_successful = false;
        }
    }

    return $all_successful;
}

// Handle form submission
if (isset($_POST['submit'])) {
    // Get form data
    $teacher_name = $_POST['teacher_name'];
    $time_slot = $_POST['time_slot'];
    $selected_courses = $_POST['courses'] ?? [];
    $selected_categories = $_POST['category'] ?? [];
    $selected_days = $_POST['days'] ?? [];

    // Check if teacher already exists
    if (teacherExists($con, $teacher_name)) {
        // Check for time slot clash
        $teacher_id_query = "SELECT teacherid FROM teachers WHERE teacher_name = ?";
        $stmt_teacher_id = mysqli_prepare($con, $teacher_id_query);
        mysqli_stmt_bind_param($stmt_teacher_id, "s", $teacher_name);
        mysqli_stmt_execute($stmt_teacher_id);
        mysqli_stmt_store_result($stmt_teacher_id);
        mysqli_stmt_bind_result($stmt_teacher_id, $teacher_id);
        mysqli_stmt_fetch($stmt_teacher_id);
        mysqli_stmt_close($stmt_teacher_id);
        
        $time_clash = false;
        foreach ($selected_courses as $course_id) {
            foreach ($selected_categories as $cat_id) {
                // Check for time slot clash for each selected course and category
                if (!insertTeacherAssignments($con, $teacher_id, $course_id, $cat_id, $selected_days, $time_slot)) {
                    $time_clash = true;
                    break;
                }
            }
            if ($time_clash) {
                break;
            }
        }
        
        if ($time_clash) {
            echo "Teacher already exists and has a clash in the time slot!";
        } else {
            echo "Teacher already exists but successfully added for the new assignment!";
        }
    } else {
        // Insert new teacher
        $inserted = insertTeacher($con, $teacher_name);
        if ($inserted) {
            // Get the teacher id
            $teacher_id = mysqli_insert_id($con);
            // Loop through selected courses and insert teacher assignments
            foreach ($selected_courses as $course_id) {
                foreach ($selected_categories as $cat_id) {
                    // Insert teacher assignments with time slot
                    insertTeacherAssignments($con, $teacher_id, $course_id, $cat_id, $selected_days, $time_slot);
                }
            }
            echo "Teacher added successfully!";
        } else {
            echo "Failed to add teacher!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Teacher</title>
</head>
<body>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-Success">Add Teacher</h2>
                    <hr>
                    <form action="" method="post">
                        <div class="form-group">
                            <label for="teacher_name">Teacher Name:</label>
                            <input type="text" class="form-control" id="teacher_name" name="teacher_name" required>
                        </div>
                        <div class="form-group">
                            <label for="time_slot">Time Slot:</label>
                            <input type="text" class="form-control" id="time_slot" name="time_slot" placeholder="e.g., 2pm-4pm" required>
                        </div>
                        <div class="form-group text-success">
                            <label for="days">Select Day:</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="monday" name="days[]" value="Monday">
                                <label class="form-check-label" for="monday">Monday</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="tuesday" name="days[]" value="Tuesday">
                                <label class="form-check-label" for="tuesday">Tuesday</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="wednesday" name="days[]" value="Wednesday">
                                <label class="form-check-label" for="wednesday">Wednesday</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="thursday" name="days[]" value="Thursday">
                                <label class="form-check-label" for="thursday">Thursday</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="checkbox" id="friday" name="days[]" value="Friday">
                                <label class="form-check-label" for="friday">Friday</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Courses:</label><br>
                            <?php 
                            // Check if there are any courses available
                            if(mysqli_num_rows($courseResult) > 0) {
                                // Display checkboxes for each course
                                while($row = mysqli_fetch_assoc($courseResult)) { 
                            ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="courses[]" value="<?php echo $row['course_id']; ?>" id="course_<?php echo $row['course_id']; ?>">
                                        <label class="form-check-label" for="course_<?php echo $row['course_id']; ?>"><?php echo $row['course_name']; ?></label>
                                    </div>
                            <?php 
                                } 
                            } else {
                                // If no courses found
                                echo "<p>No courses found.</p>";
                            }
                            ?>
                        </div>
                        <div class="form-group">
                            <label>Category:</label><br>
                            <?php if(mysqli_num_rows($categoryResult) > 0) { ?>
                                <?php while($row = mysqli_fetch_assoc($categoryResult)) { ?>
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="category[]" value="<?php echo $row['cat_id']; ?>" id="category_<?php echo $row['cat_id']; ?>">
                                        <label class="form-check-label" for="category_<?php echo $row['cat_id']; ?>"><?php echo $row['cat_name']; ?></label>
                                    </div>
                                <?php } ?>
                            <?php } else { ?>
                                <p>No categories found.</p>
                            <?php } ?>
                        </div>
                        <button type="submit" name="submit" class="btn btn-success">Add Teacher</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
