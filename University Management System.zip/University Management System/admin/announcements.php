<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();
require_once('inc/top.php');
    require_once('inc/db.php');
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Check if all form fields are set
        if(isset($_POST['title']) && isset($_POST['date']) && isset($_POST['content'])) {
            // Retrieve form data
            $title = $_POST['title'];
            $date = $_POST['date'];
            $content = $_POST['content'];

            // Prepare and execute SQL statement to insert data into the database
            $insert_query = "INSERT INTO announcements (title, date, content) VALUES ('$title', '$date', '$content')";
            $result = mysqli_query($con, $insert_query);

            if ($result) {
                // Data inserted successfully
                echo "<script>alert('Announcement submitted successfully');</script>";
            } else {
                // Error inserting data
                echo "<script>alert('Failed to submit announcement');</script>";
            }
        } else {
            // Not all form fields are set
            echo "<script>alert('Please fill out all fields');</script>";
        }
    }
?> 
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px"/><hr>
                </div>
            </div>

<div class="container mt-5">
        <h1 class="text-center bg-success text-light mb-4">Submit Announcement</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form action="announcements.php" method="POST">
                    <div class="form-group">
                        <label for="title">Title:</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Date:</label>
                        <input type="date" class="form-control" id="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label for="content">Content:</label>
                        <textarea class="form-control" id="content" name="content" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    
            </div></div><div class="row bg-dark mt-2">
        <?php include('inc/footer.php') ?>
    </div></div>
</body>
</html>