<?php
// Start output buffering and session
ob_start();
session_start();



// Include necessary files
require_once('inc/top.php');
require_once('inc/db.php');

// Check if the form is submitted
if(isset($_POST['submit'])) {
    // Retrieve subject name from the form
    $subject_name = $_POST['subject_name']; // Corrected field name

    // SQL query to insert the subject into the database
    $insertQuery = "INSERT INTO subject (subjectName) VALUES ('$subject_name')";

    // Execute the query
    $result = mysqli_query($con, $insertQuery);

    // Check if the query was successful
    if($result) {
        // Subject inserted successfully
        echo "<script>alert('Course added successfully')</script>";
        // You can redirect the user to another page after successful submission if needed
        // header('Location: success.php');
        // exit();
    } else {
        // Error occurred while inserting the subject
        echo "Error: " . mysqli_error($con);
    }
}
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px"/><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Add Class</h2><hr>
                    <form action="" method="post" >
                        <div for="subject_name" id="subject_name" name="subject_name" class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">
                                Add Class
                            </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" placeholder="Enter Course title" name="subject_name" required/>
                            </div>
                        </div>
                        <div class="form-group mt-2 row">
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <div class="offset-sm-2 col-sm-10">
                                        <button class="btn btn-outline-primary btn-block mt-2" type="submit" name="submit">Add Class</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>

</body>
</html>
