<?php
ob_start();
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Function to fetch assigned courses for a teacher with course names
function getAssignedCourses($teacherid, $con) {
    $query = "SELECT courses.course_name FROM teacher_assignments 
              INNER JOIN courses ON teacher_assignments.course_id = courses.course_id 
              WHERE teacherid = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $teacherid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $course_name);
    $courses = array();
    while (mysqli_stmt_fetch($stmt)) {
        $courses[] = $course_name;
    }
    mysqli_stmt_close($stmt);
    return implode(', ', $courses);
}

// Function to fetch assigned categories for a teacher with category names
function getAssignedCategories($teacherid, $con) {
    $query = "SELECT category.cat_name FROM teacher_assignments 
              INNER JOIN category ON teacher_assignments.cat_id = category.cat_id 
              WHERE teacherid = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $teacherid);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_bind_result($stmt, $cat_name);
    $categories = array();
    while (mysqli_stmt_fetch($stmt)) {
        $categories[] = $cat_name;
    }
    mysqli_stmt_close($stmt);
    return implode(', ', $categories);
}

?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">View All Teachers</h2>
                    <div align="right">
                        <a href="add_teachers.php" class="btn btn-outline-success">Add Teacher</a>
                        <hr>
                    </div>
                    <table class="table table-border" id="teacherTable">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Sr No</th>
                                <th>Teacher Name</th>
                                <th>Assigned Courses</th>
                                <th>Assigned Departments</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Fetch all teachers along with their assigned subjects and categories
                            $teachersQuery = "SELECT * FROM teachers";
                            $teachersResult = mysqli_query($con, $teachersQuery);

                            if(mysqli_num_rows($teachersResult) > 0) {
                                $i = 0;
                                while($row = mysqli_fetch_assoc($teachersResult)) {
                                    $i++;
                                    $teacherid = $row['teacherid'];
                                    $teacher_name = $row["teacher_name"];
                                    $assignedCourses = getAssignedCourses($teacherid, $con);
                                    $assignedCategories = getAssignedCategories($teacherid, $con);
                                    ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $teacher_name; ?></td>
                                        <td><?php echo $assignedCourses; ?></td>
                                        <td><?php echo $assignedCategories; ?></td>
                                        <td>
                                            <a class="btn btn-danger" href="display_teachers.php?del=<?php echo $teacherid; ?>"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                <?php
                                }
                            } else {
                                echo "<tr><td colspan='5'>No teachers found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px" >Export to Excel</button>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

</body>
</html>

<!-- DataTables Plugin Initialization -->
<script>
    $(document).ready(function() {
        $('#teacherTable').DataTable();
    });
</script>
