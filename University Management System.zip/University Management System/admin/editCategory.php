<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

$category_name = '';
$fees = '';

// Fetch category details if ID is provided in the URL
if(isset($_GET['cat_id'])){
    $edit_id = $_GET['cat_id'];

    if (!empty($edit_id)) { // Check if edit_id is not empty
        $category_query = "SELECT * FROM category WHERE cat_id = '$edit_id'";
        $category_result = mysqli_query($con, $category_query);

        if($category_result && mysqli_num_rows($category_result) > 0) {
            // Fetch data
            $row = mysqli_fetch_assoc($category_result);
            $category_name = $row['cat_name'];
            $fees = $row['cat_fee']; // Corrected column name to match the database

            // Debugging: Output fetched fees
            echo "Fees fetched from database: " . $fees;
        } else {
            echo "No category found with the specified ID.";
        }
    } else {
        echo "Category ID is missing.";
    }
} else {
    echo "No category ID provided.";
}

?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Edit Department Details</h2><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form action="editCategories.php?cat_id=<?php echo isset($_GET['cat_id']) ? $_GET['cat_id'] : ''; ?>" method="post" >
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">Department Name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo $category_name;?>" name="categoryName" required/>
                            </div>
                         </div>
                        
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">Fees</label>
                            <div class="col-sm-10">
                                <input type="number" class="form-control" value="<?php echo $fees;?>" name="fees" required/>
                            </div>
                        </div>
                        
                        <div class="col-sm-10">
                            <div class="form-group">
                                <div class="offset-sm-2 col-sm-10">
                                    <button class="btn btn-outline-success btn-block mt-2" type="submit" name="update">Update Category</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>

</body>
</html>

<?php
if(isset($_POST['update'])){
    // Get form data
    $categoryName = $_POST['categoryName'];
    $fees = $_POST['fees'];

    // Update query
    $update_query = "UPDATE category SET 
        cat_name = '$categoryName',
        cat_fee = '$fees' // Corrected column name to match the database
        WHERE cat_id = '$edit_id'";

    $update_result = mysqli_query($con, $update_query);
    if($update_result) {
        echo "<script>alert('Category Updated Successfully')</script>";
        echo "<script>window.open('index.php','_self')</script>";
    } else {
        echo "Error updating category: " . mysqli_error($con);
    }
}
?>
