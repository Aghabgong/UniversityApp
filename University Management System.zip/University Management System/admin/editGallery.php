<?php
     ob_start();
session_start();

 
require_once('inc/top.php');
    require_once('inc/db.php');

if($_GET['id']){
    $edit_id = $_GET['id'];
    $gallery = "SELECT * FROM gallery WHERE gallery_id = '$edit_id'";
    $runGallery = mysqli_query($con,$gallery);
    $row = mysqli_fetch_assoc($runGallery);
    $gallery_id = $row['gallery_id'];
    $gallery_title = $row['gallery_title'];
    $U_imagea = $row['gallery_img'];
    
}

?>


    <dIv class="container-fluid">
        <div class="row mt-2">
            <div class="col-md-12">
                <?php include ('inc/navbar.php')?>
                
            </div>
        </div>
        <div class="row mt-1">
            <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
             <div class="col-md-9">
                 <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
              
                 <div class="row">
                 <div class="col-md-12">
                     <h2 class="text-center text-white bg-success">Edit Gallery Images</h2><hr>
                    </div>
                     
                     <form action="" method="post" enctype="multipart/form-data" >
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">
                                Image Title
                            </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo $gallery_title?>" placeholder="Enter image title" name="Imagetitle" required/>
                            </div>
                         </div>
                         <div class="form-group mt-2 row">
                            <label class="col-sm-2 col-form-label text-danger">
                                Product Image
                            </label>
                            <div class="col-sm-10">
                                <input type="file" class="form-control file btn btn-primary" name="U_image" required/>
                                <div class="form-group">
                                    <div class="offset-sm-2 col-sm-10">
                                <button class="btn btn-outline-primary btn-block mt-2" type="submit" name="update">Update Image</button>
                                        </div>
                                    </div>
                            </div>
                             
                         </div>
                          
                     </form>
                     
                    </div>
            
        </div>
        
        <div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
    
</body>
</html>
<?php
    if(isset($_POST['update'])){
        $Imagetitle = $_POST['Imagetitle'];
        $U_image = $_FILES['U_image']['name'];
        $image_tmp = $_FILES['U_image']['tmp_name'];
        
        if(empty($U_image)){
            $U_image = $U_imagea;
        }else{
            $U_image = 'GalleryImg' .date('Y-m-d-H-i-s') .'_' .uniqid() .'jpg';
        }
        
        
        move_uploaded_file($image_tmp, "../images/gallery/$U_image");
        
        $update = "UPDATE gallery set 
        gallery_title = '$Imagetitle',
        gallery_img = '$U_image' WHERE gallery_id = '$edit_id'
        ";
        $insert_pro = mysqli_query($con,$update);
        if(isset($insert_pro)){
            echo "<script>alert('Image Updated Successfully ')</script>";
            echo "<script>window.open('gallery.php','_self')</script>";
            
        }
        
        
    }
?>