<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

if(isset($_GET['cat_name'])){
    $cat_name = $_GET['cat_name'];

    // Query to fetch student data based on category name
    $student_query = "SELECT * FROM student WHERE cat_name = '$cat_name'";
    $run_student_query = mysqli_query($con, $student_query);

    // Check if query was successful and at least one row was returned
    if($run_student_query && mysqli_num_rows($run_student_query) > 0) {
        // Loop through the results and display or process them as needed
        while ($row = mysqli_fetch_assoc($run_student_query)) {
            // Access data for each student in $row
            $id = $row['id'];
            $name = $row['name'];
            $address = $row['address'];
            $gender = $row['gender'];
            $mobile = $row['mobile'];
            $email = $row['email'];
            $fee = $row['fees'];
            $dob = $row['dob'];
            $cat_name = $row['cat_name'];
            // Assign other fields similarly
        }
    } else {
        // Handle case where no student with the given category name was found
        echo "No student found with category name: $cat_name";
        // You may choose to redirect the user or display an appropriate message
    }
} else {
    // Handle case where 'cat_name' parameter is not set in the URL
    echo "Category name not provided";
    // You may choose to redirect the user or display an appropriate message
}
?>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
           
            <div class="row">
                <div class="col-md-12">
                    <form action="" method="post" enctype="multipart/form-data">

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">Student name</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo isset($name) ? $name : ''; ?>" name="StudentName" required />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">Student Address</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo isset($address) ? $address : ''; ?>" name="StudentAddress" required />
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">Category</label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo isset($cat_name) ? $cat_name : ''; ?>" name="Category" required />
                            </div>
                        </div>

                        <!-- Add other form fields here with appropriate PHP code to populate existing values -->
                         
                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">
                            Gender
                            </label>
                            <div class="col-sm-10">
                                <select class="form-control" name="gender" required>
                                    <option value="male" <?php if(isset($gender) && $gender == 'male') echo "selected"; ?>>
                                        Male
                                    </option>
                                    <option value="female" <?php if(isset($gender) && $gender == 'female') echo "selected"; ?>>
                                        Female
                                    </option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">
                            Mobile
                            </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo isset($mobile) ? $mobile : ''; ?>" name="mobile" required/>
                            </div>
                         </div>
                         
                         <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">
                            Email
                            </label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" value="<?php echo isset($email) ? $email : ''; ?>" name="email" required/>
                            </div>
                         </div>
                         
                         <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">
                            Fees
                            </label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" value="<?php echo isset($fee) ? $fee : ''; ?>" name="fee" required/>
                            </div>
                         </div>

                        <div class="form-group row">
                            <label class="col-sm-2 col-form-label text-danger">Date of Birth</label>
                            <div class="col-sm-10">
                                <input type="date" class="form-control" value="<?php echo isset($dob) ? $dob : ''; ?>" name="dob" required />
                            </div>
                        </div>
                      
                        <!-- Submit Button -->
                        <div class="form-group mt-2 row">
                            <div class="col-sm-10 offset-sm-2">
                                <button class="btn btn-outline-success btn-block" type="submit" name="update">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>

</body>
</html>

<?php
if(isset($_POST['update'])){
    if(isset($_GET['id'])){
        $id = $_GET['id'];
    }

    $StudentName = $_POST['StudentName'];
    $StudentAddress = $_POST['StudentAddress'];
    $Category = $_POST['Category'];
    $gender = $_POST['gender'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $fee = $_POST['fee'];
    $dob = $_POST['dob']; // Getting dob value

    $update = "UPDATE student SET 
        name = '$StudentName',
        address = '$StudentAddress',
        cat_name = '$Category',
        gender = '$gender',
        mobile = '$mobile',
        email = '$email',
        fees = '$fee',
        dob = '$dob'
        WHERE id = '$id'";
    
    if(mysqli_query($con, $update)) {
        // Update successful
        echo "Update successful";
    } else {
        // Update failed
        echo "Error updating record: " . mysqli_error($con);
    }
}
?>