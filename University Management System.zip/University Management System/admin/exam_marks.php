<?php
// Start the session and include necessary files
ob_start();
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Fetch data from the exams table
$query = "SELECT s.name AS student_name, e.course_name, e.category_name, e.total_marks
          FROM exams e
          JOIN students s ON e.student_id = s.student_id";

$result = mysqli_query($con, $query); // Execute the query

// Check if data is retrieved successfully
if ($result && mysqli_num_rows($result) > 0) {
    ?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>

        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
           
            <div class="col-md-12">
                <h2 class="text-center text-white bg-secondary">Enter Obtained Marks</h2><hr>
                <form method="POST" action="">
                    <table class="table table-bordered table-condensed" id="marks_table">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Student Name</th>
                                <th>Course Name</th>
                                <th>Category Name</th>
                                <th>CA Marks</th>
                                <th>Exam Marks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Loop through each row of the result set
                            while ($row = mysqli_fetch_assoc($result)) {
                                ?>
                                <tr>
                                    <td><?php echo $row['student_name']; ?></td>
                                    <td><?php echo $row['course_name']; ?></td>
                                    <td><?php echo $row['category_name']; ?></td>
                                    <td><input type="text" name="student[<?php echo $row['student_id']; ?>][obtained_ca]"></td>
                                    <td><input type="text" name="student[<?php echo $row['student_id']; ?>][obtained_exam]"></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </tbody>
                    </table>
                    <button type="submit" class="btn btn-primary">Submit Marks</button>
                </form>
                <hr>
            </div>
        </div>
    </div>
</div>
<?php
} else {
    // Display a message if no data is found
    echo "<div class='container'><p class='text-center text-danger'>No data available.</p></div>";
}
?>
