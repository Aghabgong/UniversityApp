<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            
            <?php  
            // Check connection
            if ($con->connect_error) {
                die("Connection failed: " . $con->connect_error);
            }

            // Fetch all exams
            $sql = "SELECT * FROM exams ORDER BY cat_name, exam_date, timer";
            $result = $con->query($sql);

            // Check if query was successful
            if ($result) {
                // Check if any exams are found
                if ($result->num_rows > 0) {
                    // Initialize an array to store timetable for each category
                    $timetable = array();

                    // Loop through each row in the result set
                    while ($row = $result->fetch_assoc()) {
                        // Check if the column containing course information exists in the row array
                        if (isset($row['course_name'])) {
                            // Store exam details in a temporary array
                            $exam_details = array(
                                "examName" => $row["examName"],
                                "exam_date" => $row["exam_date"],
                                "timer" => $row["timer"],
                                "courses" => $row["course_name"]
                            );

                            // Store exam details in the timetable array organized by category and date
                            $category = $row["cat_name"];
                            $date = $row["exam_date"];
                            if (!isset($timetable[$category][$date])) {
                                $timetable[$category][$date] = array();
                            }
                            $timetable[$category][$date][] = $exam_details;
                        } else {
                            echo "Warning: Undefined array key 'course_name' on line " . __LINE__ . "<br>";
                        }
                    }

                    // Display the timetable HTML structure with Bootstrap styling
                    foreach ($timetable as $category => $category_exams) {
                        echo "<h2>Timetable for Category $category</h2>";
                        echo "<div class='table-responsive'>";
                        echo "<table class='table table-bordered table-striped'>";
                        foreach ($category_exams as $date => $exams) {
                            echo "<tr><th colspan='4'>$date</th></tr>";
                            foreach ($exams as $exam) {
                                echo "<tr><td>{$exam['examName']}</td><td>{$exam['courses']}</td><td>{$exam['time']}</td></tr>";
                            }
                        }
                        echo "</table>";
                        echo "</div>";
                    }
                } else {
                    echo "No exams found.";
                }
            } else {
                echo "Error: " . $con->error;
            }

            // Close connection
            $con->close();
            ?>
        </div>
    </div>
    <div class="row bg-dark mt-2">
        <?php include('inc/footer.php') ?>
    </div>
</div>

</body>

</html>

<script>
    $(document).ready(function () {
        $('#table2excel').DataTable();
        
        // Calculate total of checked expenses when checkbox is clicked
        $('.checked_expense').click(function() {
            var total = 0;
            $('.checked_expense:checked').each(function() {
                total += parseFloat($(this).val());
            });
            $('#total_expenses').text(total.toFixed(2));
        });

        // Calculate total of checked expenses when the page loads
        $('.checked_expense:checked').trigger('click');
        
        // Export to Excel
        $('#export_btn').click(function () {
            $("#table2excel").table2excel({
                name: "Expense_Data",
                filename: "expense_data.xls"
            });
        });
    });
</script>
