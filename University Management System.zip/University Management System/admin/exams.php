<?php
// Start session and include necessary files
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Fetch all exams from the database
$examsQuery = "SELECT * FROM exams";
$examsResult = mysqli_query($con, $examsQuery);
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success p-2 rounded">Registered Exams</h2>
                    <hr class="bg-success">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Exam Name</th>
                                    <th>Date</th>
                                    <th>Course</th>
                                    <th>Department</th>
                                    <th>Total Marks</th>
                                    <th>Exam Time</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Check if there are any exams in the database
                                if(mysqli_num_rows($examsResult) > 0) {
                                    // Output data of each exam
                                    while($row = mysqli_fetch_assoc($examsResult)) {
                                        echo "<tr>";
                                        echo "<td>" . $row["examName"] . "</td>";
                                        echo "<td>" . $row["exam_date"] . "</td>";
                                        echo "<td>" . $row["course_name"] . "</td>";
                                        echo "<td>" . $row["cat_name"] . "</td>";
                                        echo "<td>" . $row["totalMarks"] . "</td>";
                                        echo "<td>" . ($row["time"] ?? "N/A") . " minutes</td>";
                                        echo "<td><button class='btn btn-danger btn-sm' onclick='deleteExam(" . $row["exam_id"] . ")'><i class='fa fa-trash-o'></i></button></td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='7'>No exams found.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

<!-- JavaScript to handle exam deletion -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    function deleteExam(examId) {
        if (confirm("Are you sure you want to delete this exam?")) {
            $.ajax({
                type: "POST",
                url: "deleteExam.php",
                data: { examId: examId },
                success: function(response) {
                    alert(response);
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                    alert("An error occurred while deleting the exam.");
                }
            });
        }
    }
</script>

</body>
</html>
