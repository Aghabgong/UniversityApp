<?php
// Start output buffering and session
ob_start();
session_start();

// Include necessary files
require_once('inc/top.php');
require_once('inc/db.php');

// Check if the form is submitted
if(isset($_POST['submit'])) {
    // Retrieve form data and sanitize
$particular = mysqli_real_escape_string($con, $_POST['particular']);
$amount = floatval($_POST['amount']); // Convert to float
$date = $_POST['date'];

// SQL query to insert the expense into the database using prepared statement
$insertQuery = "INSERT INTO expenses (particular, amount, date) VALUES (?, ?, ?)";

    
    // Prepare the statement
    $stmt = mysqli_prepare($con, $insertQuery);
    
    // Check if the statement was prepared successfully
    if ($stmt) {
        // Bind parameters
        mysqli_stmt_bind_param($stmt, "sds", $particular, $amount, $date);
        
        // Execute the prepared statement
        $result = mysqli_stmt_execute($stmt);

        // Check if the query was successful
        if($result) {
            // Expense inserted successfully
            echo "<script>alert('Expense submitted successfully')</script>";
        } else {
            // Error occurred while inserting the expense
            echo "<script>alert('Failed to submit expense. Please try again.')</script>";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        // Error preparing the statement
        echo 'Error preparing statement: ' . mysqli_error($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expense Submission Form</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            
      <div class="container">
    <h2 class="mt-5 mb-4 bg-success text-center text-white">Expense Submission Form</h2>
    <form action="expenses.php" method="POST">
        <div class="form-group">
            <label for="particular">Particular:</label>
            <input type="text" class="form-control" id="particular" name="particular" required>
        </div>
        <div class="form-group">
            <label for="amount">Amount:</label>
            <input type="number" class="form-control" id="amount" name="amount" min="0" step="0.01" required>
        </div>
        <div class="form-group">
            <label for="date">Date:</label>
            <input type="date" class="form-control" id="date" name="date" required>
        </div>
        <button type="submit" name="submit" class="btn btn-success">Submit</button>
    </form>
</div>

        </div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>

</body>
</html>

