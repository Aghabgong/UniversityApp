<?php
require_once('inc/top.php');
require_once('inc/db.php');

if(isset($_GET['del'])){
    $del_id = $_GET['del'];
    $del_query = "DELETE FROM fees WHERE rNo = '$del_id'";
    $del_run = mysqli_query($con, $del_query);
    if($del_run){
        echo "<script>alert('Fee Record Deleted Successfully')</script>";
        echo "<script>window.open('fees.php','_self')</script>";
    }
}
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
           
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Paid Fees</h2>
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="form-group">
                        <label for="category">Select Category:</label>
                        <select class="form-control" id="category" onchange="filterByCategory()">
                            <option value="">All Categories</option>
                            <?php
                            // Fetch distinct categories from the fees table
                            $category_query = "SELECT DISTINCT cat_name FROM fees";
                            $category_result = mysqli_query($con, $category_query);
                            if ($category_result && mysqli_num_rows($category_result) > 0) {
                                while ($row = mysqli_fetch_assoc($category_result)) {
                                    $category_name = $row['cat_name'];
                                    echo "<option value='$category_name'>$category_name</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-border" id="feeRecords">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Student Name</th>
                                <th>Category</th>
                                <th>Fees</th>
                                <th>rNo</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $fees_query = "SELECT fees.*, student.name AS student_name 
                                           FROM fees 
                                           INNER JOIN student ON fees.student_id = student.id 
                                           ORDER BY fees.rNo DESC";
                            $fees_result = mysqli_query($con, $fees_query);

                            if ($fees_result && mysqli_num_rows($fees_result) > 0) {
                                while ($row = mysqli_fetch_assoc($fees_result)) {
                                    $student_name = $row['student_name'];
                                    $cat_name = $row['cat_name'];
                                    $fees = $row['fee'];
                                    $rNo = $row['rNo'];
                                    $date = $row['date'];
                                    ?>
                                    <tr>
                                        <td><?php echo $student_name; ?></td>
                                        <td><?php echo $cat_name; ?></td>
                                        <td><?php echo $fees; ?></td>
                                        <td><?php echo $rNo; ?></td>
                                        <td><?php echo $date; ?></td>
                                        <td>
                                            <a class="btn btn-danger" href="fees.php?del=<?php echo $rNo; ?>"><i class="fa fa-trash-o"></i></a>
                                        </td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                echo "<tr><td colspan='6'>No fee records found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px">Export to Excel</button>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

</body>
</html>

<script>
    function filterByCategory() {
        var selectedCategory = document.getElementById("category").value;
        var tableRows = document.getElementById("feeRecords").getElementsByTagName("tr");
        for (var i = 1; i < tableRows.length; i++) {
            var categoryCell = tableRows[i].getElementsByTagName("td")[1];
            if (selectedCategory === "" || categoryCell.textContent.trim() === selectedCategory) {
                tableRows[i].style.display = "";
            } else {
                tableRows[i].style.display = "none";
            }
        }
    }
</script>
<script>
    $(document).ready(function() {
        $('#feeRecords').DataTable();
    });

    $("#btn").click(function() {
        $("#feeRecords").table2excel({
            name: "Worksheet name",
            filename: "myExcelFile.xls"
        });
    });
</script>
