<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

if(isset($_GET['del'])){
    $del_id = $_GET['del'];
    $del_query = "DELETE FROM galerry WHERE gallery_id = '$del_id'";
    $del_run = mysqli_query($con, $del_query);

    if($del_run) {
        echo "<script>alert('Image Deleted Successfully')</script>";
        echo "<script>window.open('gallery.php','_self')</script>";
    } else {
        // Error handling
        echo "Error: " . mysqli_error($con);
    }
}
?>


<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>

        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
           
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">View All Images</h2>
                    <div align="right"><a href="addGallery.php" class="btn btn-outline-success">Add Images</a><hr>
                    </div>
                    <table class="table table-border" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <td>Sr No</td>
                                <td>Image Title</td>
                                <td>Image</td>
                                <td><a class="fa fa-pencil-square-o"></a></td>
                                <td><a class="fa fa-trash-o"></a></td>
                            </tr>
                        </thead>
                        <tbody >
                        <?php
                            $Gallery = "SELECT * FROM galerry ORDER BY gallery_id desc";
    
                            $runGallery = mysqli_query($con,$Gallery);
            $i=0;
            while($rowGallery = mysqli_fetch_assoc($runGallery)){
                $gallery_id = $rowGallery['gallery_id'];
                    $gallery_title = $rowGallery['gallery_title'];
                    $gallery_img= $rowGallery['gallery_img'];
                $i++;
            
            
                            ?>
                            <tr>
                            <td><?php echo $i?></td>
                            <td><?php echo ucfirst($gallery_title)?></td>
                            <td><img class="img-fluid" src="../images/gallery/<?php echo $gallery_img;?>" width="50px" /></td>
                            <td><a class="btn btn-warning" href="editGallery.php?id=<?php echo $gallery_id;?> "><i class="fa fa-pencil-square-o"></i></a></td>
                            <td><a class="btn btn-danger" href="gallery.php?del=<?php echo $gallery_id;?>" ><i class="fa fa-trash-o"></i></a></td>
                                </tr>
                           <?php } ?>
                        </tbody>
                    </table>
                </div>
               
               <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px" >Export to Excel</button>
            </div>
        </div>
        </div>
</div>
         <div class="row bg-dark mt-2"><?php include('inc/footer.php')?>
                </div>

       
    </body>

    </html>
<script>
    $(document).ready(function(){
        $('#table2excel').DataTable();
    });
    
</script>
<script>
  $("#btn").click(function() {
    $("#table2excel").table2excel({
      name: "Worksheet name",
      filename: "myExcelFile.xls"
    });
  });

</script>