<div class="col-md-3 text-white text-center">
    <h2 >GREEN HILLS ACADEMY COMPLEX</h2><hr>
    <p class="">© 2024<a href="index.php">G.H.A.C</a>, All rights Reserved.</p>
</div>

<div class="col-md-3">
    <h3 class=" text-white">Quick Menu</h3><hr>
    <ul>
        <li>
            <a href="#">Privacy Policy</a>
        </li>
        <li>
            <a href="#">Terms & Conditions</a>
        </li>
        <li>
            <a href="#">Disclaimer</a>
        </li>
        <li>
            <a href="contact-us.php">Contact Us</a>
        </li>
    </ul>
</div>

<div class="col-md-3 text-center">
    <h3 class=" text-white">No Off Visitors</h3>
    <h4 class=" text-white">Designed & Developed By</h4>
    <a class="btn btn-danger btn-block" href="https://web.facebook.com/jude.christar.9">AGHABGONG JUDE</a>
</div>

<div class="col-md-3 text-white text-center">
    <h3>Address</h3>
    <address>
        GREEN HILLS ACADEMY COMPLEX<br>
        Opposit Maison_Damas<br>
        Damas - Yaounde<br>
        Contact : +237652212847<br>
     </address>
</div>



