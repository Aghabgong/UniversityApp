<nav class="navbar navbar-expand-lg navbar-light bg-success p-0">
  <div class="container-fluid">
    <a class="navbar-brand text-light" href="index.php">GREEN HILLS ACADEMY COMPLEX</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active text-light" href="index.php"><i class="fa fa-home"></i>Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="addGallery.php"><i class="fa fa-camera"></i>Add Gallery</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-light" href="addStudents.php"><i class="fa fa-user"></i>Add Student</a>
        </li>
        <li class="nav-item dropdown dropdown-right">
          <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-book"></i>Create Masters
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="addCategory.php">Add Class</a>
            <a class="dropdown-item" href="addCourse.php">Add Subject</a>
            <a class="dropdown-item" href="presence.php">Present Check</a>
            <a class="dropdown-item" href="expenses.php">Expenses</a>
            <a class="dropdown-item" href="exam_timetable.php">Exam Timetable</a>
            <a class="dropdown-item" href="add_teachers.php">Add Lecturers</a>
            <a class="dropdown-item" href="add_exams.php">Add Exams</a>
              <a class="dropdown-item" href="receipts.php">Receipts</a>
            <a class="dropdown-item" href="teaching_timetable.php">Teaching Time Table</a>
            <a class="dropdown-item" href="exam_marks.php">Exam Marks</a>
              <a class="dropdown-item" href="announcements.php">Announcements</a>
          </div>
        </li>
      </ul>
      <ul class="navbar-nav ml-auto">
        <?php
        if(isset($_SESSION['admin_name'])) {
          // If logged in, show logout button
          echo '<form method="post" action="logout.php">
                  <button class="btn btn-link text-light" type="submit" name="logout"><i class="fa fa-sign-out"></i>Logout</button>
                </form>';
        } else {
          // If not logged in, show login button
          echo '<li class="nav-item dropdown dropdown-left">
                  <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa fa-cog"></i>
                  </a>
                  <div class="dropdown-menu dropdown-left" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" href="admin/login.php">Admin Login</a>
                    <!-- Add other login links as needed -->
                  </div>
                </li>';
        }
        ?>
      </ul>
    </div>
  </div>
</nav>
