<?php
$gallery_query = "SELECT * FROM galerry";
$gallery_run = mysqli_query($con, $gallery_query);
$row_gallery = ($gallery_run !== false) ? mysqli_num_rows($gallery_run) : 0;

$student_query = "SELECT * FROM student";
$student_run = mysqli_query($con, $student_query);
$row_student = ($student_run !== false) ? mysqli_num_rows($student_run) : 0;

$review_query = "SELECT * FROM review";
$review_run = mysqli_query($con, $review_query);
$row_review = ($review_run !== false) ? mysqli_num_rows($review_run) : 0;

$courses_query = "SELECT * FROM courses";
$courses_run = mysqli_query($con, $courses_query);
$row_courses = ($courses_run !== false) ? mysqli_num_rows($courses_run) : 0;

$register_query = "SELECT * FROM register";
$register_run = mysqli_query($con, $register_query);
$row_register = ($register_run !== false) ? mysqli_num_rows($register_run) : 0;

$results_query = "SELECT * FROM result";
$results_run = mysqli_query($con, $results_query);
$row_results = ($results_run !== false) ? mysqli_num_rows($results_run) : 0;

$fees_query = "SELECT * FROM fees";
$fees_run = mysqli_query($con, $fees_query);
$row_fees = ($fees_run !== false) ? mysqli_num_rows($fees_run) : 0;

$category_query = "SELECT * FROM category";
$category_run = mysqli_query($con, $category_query);
$row_category = ($category_run !== false) ? mysqli_num_rows($category_run) : 0;

$expenses_query = "SELECT * FROM expenses";
$expenses_run = mysqli_query($con, $expenses_query);
$row_expenses = ($expenses_run !== false) ? mysqli_num_rows($expenses_run) : 0;

$exams_query = "SELECT * FROM exams";
$exams_run = mysqli_query($con, $exams_query);
$row_exams = ($exams_run !== false) ? mysqli_num_rows($exams_run) : 0;

$contact_query = "SELECT * FROM contact";
$contact_run = mysqli_query($con, $contact_query);
$row_contact = ($contact_run !== false) ? mysqli_num_rows($contact_run) : 0;

$msgtoclasses_query = "SELECT * FROM msgtoclasses";
$msgtoclasses_run = mysqli_query($con, $msgtoclasses_query);
$row_msgtoclasses = ($msgtoclasses_run !== false) ? mysqli_num_rows($msgtoclasses_run) : 0;

$attendance_query = "SELECT * FROM attendance";
$attendance_run = mysqli_query($con, $attendance_query);
$row_attendance = ($attendance_run !== false) ? mysqli_num_rows($attendance_run) : 0;

$teachers_query = "SELECT * FROM teachers";
$teachers_run = mysqli_query($con, $teachers_query);
$row_teachers = ($teachers_run !== false) ? mysqli_num_rows($teachers_run) : 0;
?>


<div class="list-group">
    <a href="index.php" class="list-group-item list-group-item-action btn-success active"><i class="fa fa-tachometer"></i>Dashbord</a>
    
    <a href="gallery.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-camera"></i>Gallery<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_gallery"; ?></span>
        </button>
    </a>
    
    
    <a href="student.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-user"></i>Student<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_student"; ?></span>
        </button>
    </a>
   
     <a href="review.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-star"></i>Review<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_review"; ?></span>
        </button>
    </a>
    
    <a href="courses.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-life-ring"></i>Subjects<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_courses"; ?></span>
        </button>
    </a>
    
    <a href="register.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-lightbulb-o"></i>Registration<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_register"; ?></span>
        </button>
    </a>
    <a href="results.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-lightbulb-o"></i>Exam Results<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_results"; ?></span>
        </button>
    </a>
    
    <a href="fees.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-money"></i>Fees<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_fees"; ?></span>
        </button>
    </a>
    
    <a href="viewcategories.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-sort"></i>Classes<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_category"; ?></span>
        </button>
    </a>
    
    
    <a href="viewexpenses.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-money"></i>Expenses<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_expenses"; ?></span>
        </button>
    </a>
    
    <a href="exams.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-question"></i>Exams<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_exams"; ?></span>
        </button>
    </a>
    
    <a href="msg.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-envelope"></i>Messages<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_contact"; ?></span>
        </button>
    </a>
    
    <a href="msgtoclasses.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-window-close-o"></i>Complaints<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_msgtoclasses"; ?></span>
        </button>
    </a>
    
    <a href="display_teachers.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-graduation"></i>Teachers<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_teachers"; ?></span>
        </button>
    </a>
    
    <a href="viewattendance.php" class="list-group-item list-group-item-action mt-1">
        <i class="fa fa-"></i>Attendance<button type="button" class="btn btn-success pull-right btn-sm">
        <span class="badge badge-light text-danger"><?php echo "$row_attendance"; ?></span>
        </button>
    </a>
   
</div>