<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

// Perform database queries to fetch total fees collected and total expenses
$totalFeesQuery = "SELECT SUM(fees) AS total_fees FROM student";
$totalFeesResult = mysqli_query($con, $totalFeesQuery);
if(!$totalFeesResult) {
    die('Error: ' . mysqli_error($con));
}
$totalFeesRow = mysqli_fetch_assoc($totalFeesResult);
$totalFees = $totalFeesRow['total_fees'];

$totalExpensesQuery = "SELECT SUM(amount) AS total_expenses FROM expenses";
$totalExpensesResult = mysqli_query($con, $totalExpensesQuery);
if(!$totalExpensesResult) {
    die('Error: ' . mysqli_error($con));
}
$totalExpensesRow = mysqli_fetch_assoc($totalExpensesResult);
$totalExpenses = $totalExpensesRow['total_expenses'];

// Calculate remaining fees and remaining balance
$collectedFeesQuery = "SELECT SUM(fee) AS total_collected_fees FROM fees";
$collectedFeesResult = mysqli_query($con, $collectedFeesQuery);
if(!$collectedFeesResult) {
    die('Error: ' . mysqli_error($con));
}
$collectedFeesRow = mysqli_fetch_assoc($collectedFeesResult);
$collectedFees = $collectedFeesRow['total_collected_fees'];

$remainingFees = $totalFees - $collectedFees;
$remainingBalance = $collectedFees - $totalExpenses;

// Define and execute the expenses query
$expensesQuery = "SELECT * FROM expenses ORDER BY exp_id DESC LIMIT 10";
$runexpenses = mysqli_query($con, $expensesQuery);
if(!$runexpenses) {
    die('Error: ' . mysqli_error($con));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stat Overview of G.H.A.C</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to your CSS file -->
</head>
<body>

    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px"/><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Stat overview of G.H.A.C</h2><hr>
                </div>
                <div class="col-md-3">
                    <div class="card text-primary border-primary">
                        <div class="card-header bg-success text-white">Students</div>
                        <div class="card-body">
                            <table class='table table-bordered table-condensed'>
                                <thead>
                                    <tr>
                                        <th>Classes</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    // Query to fetch distinct category names
                                    $categoryQuery = "SELECT DISTINCT cat_name FROM student";
                                    $categoryResult = mysqli_query($con, $categoryQuery);
                                    
                                    // Iterate over distinct categories
                                    while ($categoryRow = mysqli_fetch_assoc($categoryResult)) {
                                        $categoryName = $categoryRow['cat_name'];
                                        
                                        // Query to count students in each category
                                        $studentQuery = "SELECT COUNT(*) AS total_students FROM student WHERE cat_name = '$categoryName'";
                                        $studentResult = mysqli_query($con, $studentQuery);
                                        $rowCount = mysqli_fetch_assoc($studentResult)['total_students'];
                                    ?>
                                    <tr>
                                        <td><?php echo $categoryName; ?></td>
                                        <td><?php echo $rowCount; ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <div class="card text-primary border-primary">
                        <div class="card-header bg-warning text-white">Total Fee Collected</div>
                        <div class="card-body">
                            <table class='table table-bordered table-condensed'>
                                <tbody>
                                    <tr>
                                        <th class="bg-dark text-white">Total Fees</th>
                                        <th><?php echo $totalFees; ?></th>
                                    </tr>
                                    <tr>
                                        <th class="bg-dark text-white">Collected Fees</th>
                                        <th><?php echo $collectedFees; ?></th>
                                    </tr>
                                    <tr>
                                        <th class="bg-danger text-white">Remaining Fees</th>
                                        <th><?php echo $remainingFees; ?></th>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
   <div class="card text-primary mt-2 border-primary">
    <div class="card-header bg-secondary text-white">Cash Balance</div>
    <div class="card-body">
        <table class='table table-bordered table-condensed'>
            <tbody>
                <tr>
                    <th class="bg-dark text-white">Fees Collected</th>
                    <th><?php echo $collectedFees; ?></th>
                </tr>
                <tr>
                    <th class="bg-dark text-white">Expenses</th>
                    <th><?php echo $totalExpenses; ?></th>
                </tr>
                <tr>
                    <th class="bg-danger text-white">Remaining Balance</th>
                    <th><?php echo $remainingBalance; ?></th>
                </tr>
            </tbody>
        </table>
    </div>
</div>
                </div>

                <div class="col-md-5">
                    <div class="card text-primary border-danger">
                        <div class="card-header text-white bg-danger">Expenses <small>(Last 10 Expenses)</small></div>
                        <div class="card-body">
                            <table class="table table-bordered table-condensed">
                                <thead class="bg-dark text-white">
                                    <tr>
                                        <th>Sr No</th>
                                        <th>Particular</th>
                                        <th>Amount</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $exp_id = 0;
                                    while ($rowexpenses = mysqli_fetch_assoc($runexpenses)) {
                                        $expAmnt = $rowexpenses['amount'];
                                        $particular = $rowexpenses['particular'];
                                        $date = $rowexpenses['date'];
                                        $exp_id++;
                                
                                    ?>
                                    <tr>
                                        <td><?php echo $exp_id; ?></td>
                                        <td><?php echo $particular; ?></td>
                                        <td><?php echo $expAmnt; ?></td>
                                        <td><?php echo $date; ?></td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div><div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
</div>
</body>
</html>
