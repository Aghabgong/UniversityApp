<?php
session_start();

// Debugging: Check if the logout form is submitted
if(isset($_POST['logout'])) {
    echo "Logout form submitted";
} else {
    echo "Logout form not submitted.";
}

// Perform logout process if the form is submitted
if(isset($_POST['logout'])) {
    // Destroy the session
    session_unset();
    session_destroy();
    
    // Redirect to the index page
    header('Location:../index.php');
    exit();
}
?>
