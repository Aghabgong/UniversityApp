<?php
// Start session and output buffering
ob_start();
session_start();

// Include necessary files
require_once('inc/top.php');
require_once('inc/db.php');
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            
            <div class="container-fluid text-center bg-">
                <div class="row mt-2">
                    <div class="col-md-12">
                        <h2 class="bg-success text-white ">Contact Information</h2>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6">
                        <form action="" method="POST">
                            <div class="form-group">
                                <label for="search">Search by Name or Email:</label>
                                <input type="text" class="form-control" id="search" name="search" placeholder="Enter Name or Email">
                            </div>
                            <button type="submit" class="btn btn-success" name="submit">Search</button>
                        </form>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-md-12">
                        <table class="table table-bordered">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Contact ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Mobile</th>
                                    <th>Address</th>
                                
                                    <th>Message</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Fetch data from the database
                                $query = "SELECT * FROM contact";
                                $result = mysqli_query($con, $query);

                                // Check if there are any records
                                if(mysqli_num_rows($result) > 0) {
                                    while($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>";
                                        echo "<td>".$row['contact_id']."</td>";
                                        echo "<td>".$row['con_name']."</td>";
                                        echo "<td>".$row['con_email']."</td>";
                                        echo "<td>".$row['con_mobile']."</td>";
                                        echo "<td>".$row['con_address']."</td>";
                                        
                                        echo "<td>".$row['con_message']."</td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='7'>No records found</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
    </div>
</div>

</body>
</html>
