<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get current date
    $date = date('Y-m-d');

    // Loop through each student to record attendance
    foreach ($_POST['attendance'] as $student_id => $attendance) {
        // Escape variables to protect against SQL injection
        $student_id = mysqli_real_escape_string($con, $student_id);
        $attendance = mysqli_real_escape_string($con, $attendance);

        // Insert attendance record into database
        $insert_query = "INSERT INTO attendance (student_id, date, attendance) VALUES ('$student_id', '$date', '$attendance')";
        mysqli_query($con, $insert_query);
    }
}

// Fetch all distinct category names from the student table
$category_query = "SELECT DISTINCT cat_name FROM student ORDER BY cat_name";
$category_result = mysqli_query($con, $category_query);

// Check if 'category' parameter is set in the URL
if (isset($_GET['category']) && !empty($_GET['category'])) {
    // If 'category' parameter is set, filter students by category
    $category = mysqli_real_escape_string($con, $_GET['category']);
    $students_query = "SELECT * FROM student WHERE cat_name = '$category'";
} else {
    // If 'category' parameter is not set, fetch all students
    $students_query = "SELECT * FROM student";
}
$students_result = mysqli_query($con, $students_query);
?>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <a href="courses.php" class="btn btn-success">Back To Home</a><hr>
                    <h2 class="text-center text-white bg-success">Mark Students Attendance </h2><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form method="GET" action="">
                        <div class="form-group">
                            <label for="category">Select Category:</label>
                            <select class="form-control" id="category" name="category">
                                <option value="">All Categories</option>
                                <?php while ($rowCategory = mysqli_fetch_assoc($category_result)) { ?>
                                    <option value="<?php echo $rowCategory['cat_name']; ?>" <?php if (isset($_GET['category']) && $_GET['category'] == $rowCategory['cat_name']) echo 'selected'; ?>><?php echo $rowCategory['cat_name']; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">Filter</button>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <form method="POST" action="">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Student Name</th>
                                    <th>Attendance Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($rowStudent = mysqli_fetch_assoc($students_result)) { ?>
                                    <tr>
                                        <td><?php echo $rowStudent['name']; ?></td>
                                        <td>
                                            <label class="radio-inline">
                                                <input type="radio" name="attendance[<?php echo $rowStudent['id']; ?>]" value="Present" checked> Present
                                            </label>
                                            <label class="radio-inline">
                                                <input type="radio" name="attendance[<?php echo $rowStudent['id']; ?>]" value="Absent"> Absent
                                            </label>
                                        </td>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                        <button type="submit" class="btn btn-success">Submit Attendance</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>
    </div>
</div>
