<?php
include('inc/top.php');
require_once('inc/db.php');

// Initialize search term
$search_term = '';
$search_query = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
    $search_term = $_GET['search'];
    $search_query = " AND s.name LIKE ?";
}

?>

<div class="container-fluid p-0">
    <div class="row">
        <div class="col-lg-12 mt-2">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    
    <div class="row mt-2">
        <div class="col-md-3">
            <?php include('inc/sidebar.php'); ?>
        </div>
        
        <div class="col-md-9">
            <h2 class="text-success">Receipts</h2>
            
            <!-- Search Form -->
            <form method="get" class="mb-3">
                <div class="input-group">
                    <input type="text" class="form-control" name="search" placeholder="Search by student name" value="<?php echo htmlspecialchars($search_term); ?>">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Search</button>
                    </div>
                </div>
            </form>
            
            <?php
            // Prepare the SQL query to fetch receipts
            $receipts_query = "
                SELECT r.rec_id, r.amount_paid, r.date_paid, r.balance_due, s.name AS student_name, f.cat_name AS fee_category
                FROM receipts r
                JOIN student s ON r.student_id = s.id
                JOIN fees f ON r.rNo = f.rNo
                WHERE 1=1" . $search_query . "
                ORDER BY r.date_paid DESC
            ";
            
            if ($stmt = mysqli_prepare($con, $receipts_query)) {
                if ($search_term) {
                    $search_term = "%" . $search_term . "%";
                    mysqli_stmt_bind_param($stmt, "s", $search_term);
                }
                if (mysqli_stmt_execute($stmt)) {
                    $receipts_result = mysqli_stmt_get_result($stmt);
                    
                    if ($receipts_result && mysqli_num_rows($receipts_result) > 0): ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Receipt ID</th>
                                    <th>Student Name</th>
                                    <th>Fee Category</th>
                                    <th>Amount Paid</th>
                                    <th>Date Paid</th>
                                    <th>Balance Due</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($receipt = mysqli_fetch_assoc($receipts_result)): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($receipt['rec_id']); ?></td>
                                        <td><?php echo htmlspecialchars($receipt['student_name']); ?></td>
                                        <td><?php echo htmlspecialchars($receipt['fee_category']); ?></td>
                                        <td><?php echo number_format($receipt['amount_paid'], 2); ?></td>
                                        <td><?php echo date('d M Y', strtotime($receipt['date_paid'])); ?></td>
                                        <td><?php echo number_format($receipt['balance_due'], 2); ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <p>No receipts found.</p>
                    <?php endif;
                } else {
                    echo "<p>Error executing the SQL query: " . mysqli_error($con) . "</p>";
                }
                mysqli_stmt_close($stmt);
            } else {
                echo "<p>Error preparing the SQL query: " . mysqli_error($con) . "</p>";
            }
            ?>
        </div>
    </div>
    
    <div class="container-fluid">
        <div class="row bg-dark mt-2">
            <?php include('inc/footer.php'); ?>
        </div>
    </div>
</div>

</body>
</html>
