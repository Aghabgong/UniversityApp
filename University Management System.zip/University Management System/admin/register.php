<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

if(isset($_GET['del'])){
    $del_id = $_GET['del'];
    $del_query="DELETE FROM student WHERE id = '$del_id' ";
    $del_run = mysqli_query($con,$del_query);
    if($del_run){
        echo "<script>alert('Student Deleted Successfully')</script>";
        echo "<script>window.open('student.php','_self')</script>";
    }
}
?>


<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">View All Registered</h2>
                    <table class="table table-border" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Sr No</th>
                                <th>Student Name</th>
                                <th>Department</th>
                                <th>Course</th>
                                <th>Exam Name</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $register = "SELECT * FROM register ORDER BY regid DESC";
                            $runregister = mysqli_query($con, $register);
                            $i = 0;
                            while($rowregister = mysqli_fetch_assoc($runregister)){
                                $regName = $rowregister['student_name'];
                                $regcat = $rowregister['cat_name'];
                                $regcousre = $rowregister['course_name'];
                                $exam_id = $rowregister['exam_id'];
                                
                                // Fetching exam name using exam_id from the exam table
                                $exam_query = "SELECT examName FROM exams WHERE exam_id = '$exam_id'";
                                $exam_result = mysqli_query($con, $exam_query);

                                // Check if query executed successfully
                                if ($exam_result) {
                                    $exam_row = mysqli_fetch_assoc($exam_result);
                                    $regexam = $exam_row['examName'];
                                } else {
                                    // Handle the case where the query fails
                                    $regexam = "Unknown Exam"; // or any default value you want
                                }
                                
                                $date = $rowregister['date'];
                                $i++;
                            ?>
                            <tr>
                                <td><?php echo $i?></td>
                                <td><?php echo ucfirst($regName);?></td>
                                <td><?php echo $regcat;?></td>
                                <td><?php echo $regcousre;?></td>
                                <td><?php echo $regexam;?></td>
                                <td><?php echo $date;?></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px" >Export to Excel</button>
            </div>
        </div>
    </div>
</div>
<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
</body>
</html>
<script>
    $(document).ready(function(){
        $('#table2excel').DataTable();
    });
</script>
<script>
    $("#btn").click(function() {
        $("#table2excel").table2excel({
            name: "Worksheet name",
            filename: "myExcelFile.xls"
        });
    });
</script>
