<?php
// Start the session and include necessary files
ob_start();
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Fetch data from the result table, joining with the student table to get student name
$query = "SELECT s.name AS student_name, r.course_name, r.cat_name, r.date, r.CA, r.Obtained_ca, r.exam_marks, r.obtainedMarks, r.gen_total, r.total_ob_marks
          FROM result r
          JOIN student s ON r.student_id = s.student_id";
$result = mysqli_query($con, $query);

?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>

        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            
            <div class="col-md-12">
                <h2 class="text-center text-white bg-secondary">Marks Data</h2><hr>
                <table class="table table-bordered table-condensed" id="marks_table">
                    <thead class="bg-dark text-white">
                        <tr>
                            <th>Student Name</th>
                            <th>Course Name</th>
                            <th>Department</th>
                            <th>Date</th>
                            <th>CA</th>
                            <th>Obtained CA</th>
                            <th>Exam Marks</th>
                            <th>Obtained Marks</th>
                            <th>Total Marks</th>
                            <th>Total Obtained Marks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Loop through each row of the result set
                        if ($result && mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_assoc($result)) {
                                echo "<tr>";
                                echo "<td>" . $row['student_name'] . "</td>";
                                echo "<td>" . $row['course_name'] . "</td>";
                                echo "<td>" . $row['cat_name'] . "</td>";
                                echo "<td>" . $row['date'] . "</td>";
                                echo "<td>" . $row['CA'] . "</td>";
                                echo "<td>" . $row['Obtained_ca'] . "</td>";
                                echo "<td>" . $row['exam_marks'] . "</td>";
                                echo "<td>" . $row['obtainedMarks'] . "</td>";
                                echo "<td>" . $row['gen_total'] . "</td>";
                                echo "<td>" . $row['total_ob_marks'] . "</td>";
                                echo "</tr>";
                            }
                        } else {
                            // Display a message if no data is found
                            echo "<tr><td colspan='10' class='text-center text-danger'>No data available.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
                <hr>
            </div>
        </div>
    </div>
</div>
