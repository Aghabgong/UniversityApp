<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <?php
            // Fetch review data from the database
            $reviews_query = "SELECT * FROM review";
            $reviews_result = mysqli_query($con, $reviews_query);
            ?>

            <!-- Display the review data in a table -->
            <div class="container">
                <h2>Review Data</h2>
                <div class="table-responsive">
                    <table class="table table-striped" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Review ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Rating</th>
                               
                                <th>Message</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Check if there are any reviews in the database
                            if (mysqli_num_rows($reviews_result) > 0) {
                                // Output data of each row
                                while ($row = mysqli_fetch_assoc($reviews_result)) {
                                    echo "<tr>";
                                    echo "<td>" . $row["review_id"] . "</td>";
                                    echo "<td>" . $row["review_name"] . "</td>";
                                    echo "<td>" . $row["review_email"] . "</td>";
                                    echo "<td>" . $row["review_rating"] . "</td>";
                                   
                                    echo "<td>" . $row["review_msg"] . "</td>";
                                    echo "<td>" . $row["review_date"] . "</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No reviews found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                <div class="row mt-2">
                    <div class="col-md-4 offset-md-4">
                        <button class="btn btn-warning btn-block" id="btn" type="button">Export to Excel</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row bg-dark mt-2">
        <?php include('inc/footer.php') ?>
    </div>
</div>

</body>

</html>
<script>
    $(document).ready(function() {
        $('#table2excel').DataTable();
    });

    $("#btn").click(function() {
        $("#table2excel").table2excel({
            name: "Worksheet name",
            filename: "myExcelFile.xls"
        });
    });
</script>
