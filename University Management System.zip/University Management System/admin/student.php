<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

if(isset($_GET['del'])){
    $del_id = $_GET['del'];
    $del_query="DELETE FROM student WHERE id = '$del_id' ";
    $del_run = mysqli_query($con,$del_query);
    if($del_run){
        echo "<script>alert('Student Deleted Successfully')</script>";
        echo "<script>window.open('student.php','_self')</script>";
    }
}
?>


<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
             <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">View All Students</h2>
                    <div align="right"><a href="addStudents.php" class="btn btn-outline-success">Add Student</a><hr>
                    </div>
                    <table class="table table-border" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Sr No</th>
                                <th>Student Name</th>
                                <th>Category</th>
                                <th>Image</th>
                                <th><a class="fa fa-eye"></a></th>
                                <th><a class="fa fa-pencil-square-o"></a></th>
                                <th><a class="fa fa-trash-o"></a></th>
                            </tr>
                        </thead>
                        <tbody >
                        <?php
                            $Student = "SELECT * FROM student ORDER BY id desc";

                            $runStudent = mysqli_query($con,$Student);
                            $i=0;
                            while($rowStudent = mysqli_fetch_assoc($runStudent)){
                                $id = $rowStudent['id'];
                                $name = $rowStudent['name'];
                                $cat_name = $rowStudent['cat_name']; // Assuming cat_name is the column name for category name in student table
                                $image= $rowStudent['image'];
                                $i++;
                            ?>
                            <tr>
                                <td><?php echo $i?></td>
                                <td><?php echo ucfirst($name);?></td>
                                <td><?php echo $cat_name;?></td>
                                <td><img class="img-fluid" src="../images/advert/<?php echo $image;?>" width="50px" /></td>
                                <td><a class="btn btn-success" href="studentDetails.php?id=<?php echo $id;?> "><i class="fa fa-eye"></i></a>
                                </td>
                                <td><a class="btn btn-warning" href="editStudent.php?cat_name=<?php echo $cat_name;?> "><i class="fa fa-pencil-square-o"></i></a></td>
                                <td><a class="btn btn-danger" href="student.php?del=<?php echo $id;?>" ><i class="fa fa-trash-o"></i></a></td>
                            </tr>
                           <?php } ?>
                        </tbody>
                    </table>
                    <!-- Total Student Count -->
                    <div class="col-md-12">
                        <p>Total Students: <?php echo $i; ?></p>
                    </div>
                </div>
               
               <button class="btn btn-warning offset-md-4 mt-2" id="btn" type="button" style="width:200px" >Export to Excel</button>
            </div>
        </div>
    </div>
</div>
<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>

</body>
</html>

<script>
    $(document).ready(function(){
        $('#table2excel').DataTable();
    });
    
</script>
<script>
  $("#btn").click(function() {
    $("#table2excel").table2excel({
      name: "Worksheet name",
      filename: "myExcelFile.xls"
    });
  });
</script>
