<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');
?>


<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include ('inc/navbar.php')?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php')?></div>
        <div class="col-md-9">
            
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px"/><hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Student Details</h2>
                </div>
                <?php 
                if(isset($_GET['id'])){       
                    $user_id = $_GET['id'];
                    
                    // Prepared statement to prevent SQL injection
                    $selectStudent = "SELECT s.*, s.cat_name 
                                      FROM student s
                                      WHERE s.id = ?";
                    $stmt = mysqli_prepare($con, $selectStudent);
                    if (!$stmt) {
                        die('Error: ' . mysqli_error($con));
                    }
                    mysqli_stmt_bind_param($stmt, "i", $user_id);
                    if (mysqli_stmt_execute($stmt)) {
                        $result = mysqli_stmt_get_result($stmt);

                        if ($result) {
                            if (mysqli_num_rows($result) > 0) {
                                $row = mysqli_fetch_assoc($result);

                                // Assign fetched values to variables
                                $id = $row['id'];
                                $name = $row['name'];
                                $address = $row['address'];
                                $gender = $row['gender'];
                                $mobile = $row['mobile'];
                                $email = $row['email'];
                                $fee = $row['fees'];
                                $dob = $row['dob'];
                                $date = $row['date'];
                                $cat_name = $row['cat_name'];

                                // Output the student details
                                echo "
                                <div class='col-md-4'>
                                    <table class='table table-responsive table-bordered table-condensed'>
                                        <tbody>
                                            <tr>
                                                <th class='bg-dark text-white'> Name</th>
                                                <th>$name</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Address</th>
                                                <th>$address</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Email</th>
                                                <th>$email</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Category</th>
                                                <th>$cat_name</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Gender</th>
                                                <th>$gender</th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                                <div class='col-md-4'>
                                    <table class='table table-responsive table-bordered table-condensed'>
                                        <tbody>
                                            <tr>
                                                <th class='bg-dark text-white'> Fees</th>
                                                <th>$fee</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Date of Birth</th>
                                                <th>$dob</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Mobile</th>
                                                <th>$mobile</th>
                                            </tr>
                                            <tr>
                                                <th class='bg-dark text-white'> Registration Date</th>
                                                <th>$date</th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                               <div class='col-md-4'>";
    
    // Fetch the student's photo filename from the database
    $photo_filename = $row['image']; // Assuming 'image' is the column name for the photo filename

    // Directory where student photos are stored
    $photo_directory = '../images/advert/';

    // Full path to the student's photo
    $photo_path = $photo_directory . $photo_filename;

    // Check if the photo file exists
    if (file_exists($photo_path)) {
        // If the photo file exists, display the student's photo
        echo "<img src='$photo_path' width='100%' class='img-fluid rounded-start' alt='Student Photo'>";
    } else {
        // If the photo file does not exist, display a default placeholder image
        echo "<img src='../images/default_photo.jpg' width='100%' class='img-fluid rounded-start' alt='Default Photo'>";
    }
 
echo "</div>
                                </div>";
                            } else {
                                echo "No Student Found";
                            }
                        } else {
                            echo "Error: " . mysqli_error($con);
                        }
                    } else {
                        echo "Error: Failed to execute the prepared statement.";
                    }
                    mysqli_stmt_close($stmt);
                }
                ?>
            <hr>
       <div class="row">
    <h2 class="text-center text-white bg-success">Fees Details</h2>
    <div class="col-md-4">
        <form action="" method="post">
            <div class="form-group row">
                <label class="col-sm-6 col-form-label text-dark">Add Fee Amt</label>
                <div class="col-sm-6">
                    <input class="form-control" type="text" placeholder="Fees Paid" name="feespaid">
                </div>
            </div>
            <div class="form-group row">
                <label class="offset-sm-6 col-sm-6">
                    <button class="btn btn-success" name="addFees">Add Fees</button>
                </label>
            </div>
            <div class="form-group row">
            </div>
        </form>
    </div>
    <div class="col-md-4">
        <table class="table text-center table-bordered table-condensed">
            <?php
            // Code for fetching student's details
            if(isset($_GET['id'])){       
                $user_id = $_GET['id'];
                $seclectStudent = "SELECT * FROM student WHERE id = '$user_id'";
                $run = mysqli_query($con,$seclectStudent);
                if (mysqli_num_rows($run) > 0) {
                    $row = mysqli_fetch_assoc($run);
                    $id = $row['id']; // Assign the value to $id inside the if block

                    // Fetching fees paid by the student
                    $stdsFeePaid = "SELECT * FROM fees WHERE student_id = '$id'";
                    $runstdPaid = mysqli_query($con,$stdsFeePaid);
                    $tFees = 0;
                    $feesPaid = 0;

                    // Displaying fees details
                    while($rowstdPaid = mysqli_fetch_assoc($runstdPaid)){
                        $feesPaid = $rowstdPaid['fee'];
                        $paidDate = $rowstdPaid['date'];
                        $RNo = $rowstdPaid['rNo'];
                        $tFees += $feesPaid;
            ?>
                        <tbody>
                            <tr>
                                <th class="bg-dark text-white"><?php echo $paidDate;?></th>
                                <th>Rs <?php echo $feesPaid;?></th>
                                <th>Receipt No<?php echo $RNo;?></th>
                            </tr>
                        </tbody>
            <?php 
                    }
                } else {
                    echo "No Student Found";
                }
            }
            ?>
        </table>
    </div>
    <div class="col-md-4">
        <table class="table table-bordered table-condensed">
            <tbody>
                <tr>
                    <th class="bg-dark text-white">Fees</th>
                    <th>Frs <?php echo $fee; ?></th>
                </tr>
                <tr>
                    <th class="bg-dark text-white">Paid Fees</th>
                    <th>Frs <?php echo $tFees; ?></th>
                </tr>
                <tr>
                    <th class="bg-danger text-white">Balance</th>
                    <th>Frs <?php echo $fee - $tFees; ?></th>
                </tr>
            </tbody>
        </table>
    </div>
</div><hr>
                 
<div class="row">
    <div class="col-md-8">
        <h2 class="text-center text-white bg-secondary">Marks Allocation</h2><hr>
        <table class="table table-bordered table-condensed" id="table2excel">
            <thead class="bg-dark text-white">
                <tr>
                    <th>Date</th>
                    <th>Course</th>
                    <th>Total Marks</th>
                    <th>Obtained Marks</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if(isset($_GET['id'])) {
                    $user_id = $_GET['id'];
                    $result = "SELECT * FROM result WHERE student_id = '$user_id'";
                    $run_result = mysqli_query($con,$result);
                    
                    while($row_result = mysqli_fetch_assoc($run_result)){
                        $date = $row_result['date'];
                        $course = $row_result['course'];
                        $totalMarks = $row_result['totalMarks'];
                        $obtainedMarks = $row_result['obtainedMarks'];
                ?>
                <tr>
                    <td><?php echo $date; ?></td>
                    <td><?php echo $course; ?></td>
                    <td><?php echo $totalMarks; ?></td>
                    <td><?php echo $obtainedMarks; ?></td>
                </tr>
                <?php };?>
            </tbody>
        </table><hr>
    </div>
    <div class="col-md-4">
        <h2 class="text-center bg-success text-white">Attendance Details</h2><hr>
        <div class="row ">
            <?php 
            $present = "SELECT * from attendance Where student_id = '$user_id' && attendance = 'Present'";
            $run_present = mysqli_query($con,$present);
            $row_present = mysqli_num_rows($run_present);
            
            $absent = "SELECT * from attendance Where student_id = '$user_id' && attendance = 'Absent'";
            $run_absent = mysqli_query($con,$absent);
            $row_absent = mysqli_num_rows($run_absent);
            ?>
            <div class="col-md-12">
                <button type="button" class="btn btn-info btn-block">Present Days<span class="badge badge-light"><?php echo $row_present;?></span></button>
            </div>
            <div class="col-md-12 mt-2">
                <button type="button" class="btn btn-danger btn-block">Absent Days<span class="badge badge-light"><?php echo $row_absent;?></span></button>
            </div>
        </div>
    </div>
</div>
</div>
</body>
</html>
<script>
    $(document).ready(function(){
        $('#table2excel').DataTable();
    });
    
</script>
<script>
    $(document).ready(function(){
        $('#newtable2excel').DataTable();
    });
    
</script>
<div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
        
<?php 
if(isset($_POST['addFees'])){
    $feespaid = $_POST['feespaid'];
    
    // Assuming $user_id and $cat_name are already defined
    $insertFees = "INSERT INTO fees (student_id, cat_name, fee, date) VALUES ('$user_id', '$cat_name', '$feespaid', NOW())";
        
    $insert_pro = mysqli_query($con, $insertFees);
    if($insert_pro){
        echo "<script>alert('Fees added Successfully')</script>";
        echo "<script>window.open('fees.php','_self')</script>";
    }
}
                }
?>
            