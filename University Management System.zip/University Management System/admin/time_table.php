<?php
// Start session and include necessary files
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Check database connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Define days of the week
$days = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday');

// Define categories
$categoriesQuery = "SELECT * FROM category";
$categoriesResult = mysqli_query($con, $categoriesQuery);
$categories = array();
if (!$categoriesResult) {
    die('Error fetching categories: ' . mysqli_error($con));
}
while ($categoryRow = mysqli_fetch_assoc($categoriesResult)) {
    $categories[$categoryRow['cat_id']] = $categoryRow['cat_name'];
}

// Fetch all records from the teacher_assignments table along with course and teacher details
$assignmentsQuery = "SELECT ta.day_of_week, t.teacher_name, c.course_name, ta.cat_id
                     FROM teacher_assignments ta
                     INNER JOIN teachers t ON ta.teacherid = t.teacherid
                     INNER JOIN courses c ON ta.course_id = c.course_id";
$assignmentsResult = mysqli_query($con, $assignmentsQuery);
if (!$assignmentsResult) {
    die('Error fetching assignments: ' . mysqli_error($con));
}

// Initialize an array to store timetable data
$timetable = array();
// Initialize timetable structure
foreach ($days as $day) {
    $timetable[$day] = array_fill_keys(array_keys($categories), array());
}

// Loop through each assignment record
while ($row = mysqli_fetch_assoc($assignmentsResult)) {
    $dayOfWeek = $row['day_of_week'];
    $teacherName = $row['teacher_name'];
    $courseName = $row['course_name'];
    $categoryId = $row['cat_id'];
    // Add the teacher to the respective category for the given day
    $timetable[$dayOfWeek][$categoryId][] = array('teacher_name' => $teacherName, 'course_name' => $courseName);
}
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php'); ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Timetable</h2>
                    <hr>
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Day</th>
                                <?php foreach ($categories as $categoryId => $categoryName): ?>
                                    <th><?php echo $categoryName; ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($timetable as $day => $assignments): ?>
                                <tr>
                                    <td><?php echo $day; ?></td>
                                    <?php foreach ($assignments as $categoryId => $teachers): ?>
                                        <td>
                                            <?php foreach ($teachers as $teacher): ?>
                                                <?php echo $teacher['teacher_name'] . ' - ' . $teacher['course_name'] . '<br>'; ?>
                                            <?php endforeach; ?>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

</body>
</html>
