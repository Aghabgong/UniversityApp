<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-3"><?php include('inc/sidebar.php') ?></div>
        <div class="col-md-9">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo1.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <?php
            // Fetch expense data from the database
            $expenses_query = "SELECT * FROM expenses";
            $expenses_result = mysqli_query($con, $expenses_query);
            ?>

            <!-- Display the expense data in a table -->
            <div class="container">
                <h2>Expense Data</h2>
                <div class="table-responsive">
                    <form action="" method="post">
                        <table class="table table-striped" id="table2excel">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Expense ID</th>
                                    <th>Particular</th>
                                    <th>Amount</th>
                                    <th>Date</th>
                                    <th>Select</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $total_expenses = 0; // Initialize total expenses variable
                                // Check if there are any expenses in the database
                                if (mysqli_num_rows($expenses_result) > 0) {
                                    // Output data of each row
                                    while ($row = mysqli_fetch_assoc($expenses_result)) {
                                        echo "<tr>";
                                        echo "<td>" . $row["exp_id"] . "</td>";
                                        echo "<td>" . $row["particular"] . "</td>";
                                        echo "<td>" . $row["amount"] . "</td>";
                                        echo "<td>" . $row["date"] . "</td>";
                                        echo "<td><input type='checkbox' class='checked_expense' name='checked_expenses[]' value='" . $row["amount"] . "'></td>";
                                        echo "</tr>";
                                        // Add the amount to total expenses
                                        $total_expenses += $row["amount"];
                                    }
                                } else {
                                    echo "<tr><td colspan='5'>No expenses found.</td></tr>";
                                }
                                ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="3">Total Expenses</th>
                                    <th id="total_expenses"><?php echo $total_expenses; ?></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                        <button type="button" class="btn btn-success" id="export_btn">Export to Excel</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row bg-dark mt-2">
        <?php include('inc/footer.php') ?>
    </div>
</div>

</body>

</html>

<script>
    $(document).ready(function () {
        $('#table2excel').DataTable();
        
        // Calculate total of checked expenses when checkbox is clicked
        $('.checked_expense').click(function() {
            var total = 0;
            $('.checked_expense:checked').each(function() {
                total += parseFloat($(this).val());
            });
            $('#total_expenses').text(total.toFixed(2));
        });

        // Calculate total of checked expenses when the page loads
        $('.checked_expense:checked').trigger('click');
        
        // Export to Excel
        $('#export_btn').click(function () {
            $("#table2excel").table2excel({
                name: "Expense_Data",
                filename: "expense_data.xls"
            });
        });
    });
</script>
