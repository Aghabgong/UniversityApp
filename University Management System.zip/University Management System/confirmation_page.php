<?php
ob_start();
session_start();
require_once('inc/db.php');

if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);
    
    // Hash the new password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Update the password in the database
    $update_password_query = "UPDATE student_registration SET password = '$hashed_password', reset_token = NULL WHERE email = '$email'";
    $update_password_result = mysqli_query($con, $update_password_query);
    
    if($update_password_result){
        // Password updated successfully
        echo "Password updated successfully. You can now login with your new password.";
    } else {
        // Handle database error
        echo "Error updating password.";
    }
}
// After successful submission and token update
if ($update_token_result) {
    // Redirect the user to a confirmation page
    header("Location: confirmation_page.php");
    exit(); // Make sure to stop further execution after redirection
} else {
    // Handle the case where the update fails
    echo "Error updating reset token.";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>
        <form method="post">
            <div class="form-group">
                <label for="password">New Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Reset Password</button>
        </form>
    </div>
</body>
</html>
