<?php
include('inc/top.php');


// Include database connection file
require_once('inc/db.php');
// Fetch data from the database
$query = "SELECT * FROM contact"; // Using the table name 'contacts'
$result = mysqli_query($con, $query);
// Check if the query was executed successfully
if (!$result) {
    die("Error executing the query: " . mysqli_error($con));
}
// Handle form submission
if(isset($_POST['submit'])) {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $department = $_POST['qualification'];
    $message = $_POST['message'];

    // Insert data into database
    $insert_query = "INSERT INTO contact (con_name, con_email, con_mobile, con_address, cat_name, con_message) 
                     VALUES ('$name', '$email', '$mobile', '$address', '$department', '$message')";
    $insert_result = mysqli_query($con, $insert_query);

    if($insert_result) {
        // Data inserted successfully
        echo "<script>alert('Student Registered Successfully')</script>";
        echo "<script>window.open('index.php','_self')</script>";
        exit(); // Terminate script after redirection
    } else {
        // Error inserting data
        echo "Error: " . mysqli_error($con);
    }
}
?>

<div class="container-fluid p-0">
    <div class="row">
        <div class="col-lg-12 mt-2">
            <?php include('inc/navbar.php'); ?>
            
        </div>
    </div>
    
    <div class="row mt-2" >
        <div class="col-md-4">
            <h2 class="text-success">Apply For Admission</h2><hr>
            <form action="" method="post" id="admissionForm">
                <div class="form-group row mt-2">
                    <div class="col-sm-2 col-form-label text-dark">Name</div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" placeholder="Enter Your Name" style="border:1px solid black; padding-left:5px" name="name" required/>
                    </div>
                </div>
                <div class="form-group row mt-2">
                    <div class="col-sm-2 col-form-label text-dark">Email</div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" placeholder="Enter Your Email" style="border:1px solid black; padding-left:5px" name="email" id="email" required/>
                    </div>
                </div>
                <div class="form-group row mt-2">
                    <div class="col-sm-2 col-form-label text-dark">Mobile</div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" placeholder="Enter Your Mobile" style="border:1px solid black; padding-left:5px" name="mobile" id="mobile" required/>
                    </div>
                </div>
                <div class="form-group row mt-2">
                    <div class="col-sm-2 col-form-label text-dark">Address</div>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" placeholder="Enter Your Address" style="border:1px solid black; padding-left:5px" name="address" required />
                    </div>
                </div>
                <div class="form-group row mt-2">
                    <label class="col-sm-2 col-form-label text-dark">Class</label>
                    <div class="col-sm-10">
                        <select class="form-control" name="qualification" style="border:1px solid black; padding-left:5px" required>
                            <option value="">Select Category</option>
                            <?php
                            // Fetch categories from the database
                            $category_query = "SELECT cat_name FROM category";
                            $category_result = mysqli_query($con, $category_query);
                            while ($row = mysqli_fetch_assoc($category_result)) {
                                echo "<option value='" . $row['cat_name'] . "'>" . $row['cat_name'] . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="form-group row mt-2">
                    <label class="col-sm-2 col-form-label text-dark">Message</label>
                    <div class="col-sm-10">
                        <textarea class="form-control" placeholder="Enter Your Message" name="message" rows="4"></textarea>
                    </div>
                </div>
            
                <div class="form-group row mt-2">
                  
                    <div class="offset-sm-2 col-sm-10">
                       <button class="btn btn-success" name="submit">Submit</button>
                    </div>
                </div>
            </form>
            
        </div>
        <div class="col-md-5 table-responsive">
            <table class="table table-bordered">
                <thead class="bg-dark text-white">
                    <tr>
                        <td>Sr No</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Mobile</td>
                        <td>Address</td>
                      
                       
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Iterate through the fetched data and generate table rows
                    $i = 1;
                    while($row = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['con_name']; ?></td>
                        <td><?php echo $row['con_email']; ?></td>
                        <td><?php echo $row['con_mobile']; ?></td>
                        <td><?php echo $row['con_address']; ?></td>
                       
                       
                    </tr>
                    <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
       
            <div class="col-md-3 bg-success text-white">
            <h3>Address</h3>
    <address>
        GREEN HILLS ACADEMY COMPLEX<br>
        DAMAS - YAOUNDE<br>
        Opposit Maison Damas<br>
        Contact : +237650702580<br>
     </address>
            <img class="img-fluid" src="./images/logo.jpg" />
            
        </div>
    
    </div>
    
    <div class="container-fluid">
        <div class="row bg-dark mt-2">
            <?php include('inc/footer.php'); ?>
        </div>
    </div>
</div>

</body>
</html>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // Function to validate email address
    function isValidEmail(email) {
        var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    // Function to validate phone number
    function isValidPhoneNumber(phoneNumber) {
        var regex = /^\+\d{10,}$/;
        return regex.test(phoneNumber);
    }

    // Form submission handler
    document.getElementById("admissionForm").addEventListener("submit", function(event) {
        var email = document.getElementById("email").value;
        var phoneNumber = document.getElementById("mobile").value;

        // Validate email
        if (!isValidEmail(email)) {
            alert("Please enter a valid email address.");
            event.preventDefault(); // Prevent form submission
            return;
        }

        // Validate phone number
        if (!isValidPhoneNumber(phoneNumber)) {
            alert("Please enter a valid phone number in international format (+1234567890).");
            event.preventDefault(); // Prevent form submission
            return;
        }

        // If both email and phone number are valid, allow form submission
    });
});
</script>
