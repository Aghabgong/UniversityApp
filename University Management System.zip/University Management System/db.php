<?php
$db['db_host'] = 'localhost';
$db['db_user'] = 'root';
$db['db_password'] = '';
$db['db_name'] = 'data';

$con = mysqli_connect($db['db_host'], $db['db_user'], $db['db_password'], $db['db_name']);

if(isset($_POST['submit'])){
    
     $name = mysqli_real_escape_string($con, $_POST['name']); 
    $password = mysqli_real_escape_string($con, $_POST['password']);
    
    $insert = "INSERT INTO candy(can_name, can_pass) VALUES('$name', '$password')";
    $insert_pro = mysqli_query($con, $insert);
    if($insert_pro){
        echo "Data submitted successfully";
    } else {
        echo "Error: " . mysqli_error($con);
    }
}
?>
<div class="row">
    <div class="col-md-12">
        <h2 class="text-center text-white bg-primary">Add Student</h2><hr>
    </div>
                     
    <form action="" method="post" >
        <div class="form-group row">
            <label class="col-sm-2 col-form-label text-danger">
                Student name
            </label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Enter student name" name="name" required/>
            </div>
        </div>
                         
        <div class="form-group row">
            <label class="col-sm-2 col-form-label text-danger">
                Password
            </label>
            <div class="col-sm-10">
                <input type="text" class="form-control" placeholder="Enter student password" name="password" required/>
            </div>
        </div>
        <button type="submit" name="submit">Submit</button>
    </form>
</div>