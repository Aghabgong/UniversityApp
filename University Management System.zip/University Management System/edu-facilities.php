<?php
include('inc/top.php');


?>

<div class="container-fluid p-0">
    <div class="row">
        <div class="col-lg-12 mt-2">
            <?php include('inc/navbar.php'); ?>
            
        </div>
    </div>
    
    <div class="row mt-2" >
        <div class="col-md-9">
          <h2 class="text-center bg-secondary text-white">Educational Facilities</h2><hr>
            <div class="row">
                <div class="col-md-12 text-justify">
                    <ol>
                         <li>
                        <h4 class="text-danger text-justify"> Concession Given to Economically Backward Students:</h4>
                             <small class="text-justify"> Available and availed to students whose parents income from all sources is less than 50000FCFA</small>
                         </li>
                        <li>
                        <h4 class="text-danger text-justify"> Scholarships awarded to freedom fighters.</h4>
                            
                         </li>
                        <li>
                        <h4 class="text-danger text-justify"> Coaching for students who desire to enter into the Civil Service:</h4>
                             <small class="text-justify"></small>
                         </li>
                                                 <li>
                        <h4 class="text-danger text-justify"> Government Scholarship and Concession:</h4>
                             <small class="text-justify"> Students Scoring mor than 85% of the GCE Results can get government open merit Scholarships. Eligible students can apply for various types of scholarships and such as </small>
                                                     <ol>
                                                       <li><small>States Scholarships for Backward Students</small></li>
                                                     <li><small>Scholarship/Fee concession for the physically handicapped students</small></li>
                                                     </ol>
                         </li>
                    <li>
                        <h4 class="text-danger text-justify"> Concession Given to Economically Backward Students</h4>
                             <small class="text-justify"> Available and availed to students whose parents income from all sources is less than 50000FCFA</small>
                         </li>
                     </ol>
                    <p><b class="text-danger text-justify">Special Note:</b>No Scholarship will be paid to any student unless and untill it is received by the school from the respective government/State/Central. Students who do not appear for the final exams are not eligible.</p>
                </div>
                
            </div>
          
            
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h3 class="card-title text-center">DIRECTOR</h3>
                </div>
            </div>
            <img src="images/students%20(1).jpg" class="img-fluid"/>
        </div>
    </div>
    
    <div class="container-fluid">
        <div class="row bg-dark mt-2">
        <?php include('inc/footer.php'); ?>
    </div>
    </div>
</div>

</body>
</html>