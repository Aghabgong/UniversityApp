<?php
ob_start();
session_start();
// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['student_name'])) {
    header('Location: student_login.php');
    exit();
}
require_once('inc/top.php');
require_once('inc/db.php');
?>
<style>
.card-img-top{
    width: 100%;
    height: 300px;
    object-fit: contain;
}
</style>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="row">
            <div class="col-md-12">
                <img src="images/logo.jpg" class="img-fluid" width="70px" />
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center text-white bg-success">Gallery Images</h2>
                <div align="right">
                    <hr>
                </div>
                <div class="row">
                    <?php
                    $galleryQuery = "SELECT * FROM galerry ORDER BY gallery_id DESC";
                    $runGallery = mysqli_query($con, $galleryQuery);
                    while ($rowGallery = mysqli_fetch_assoc($runGallery)) {
                        $gallery_id = $rowGallery['gallery_id'];
                        $gallery_title = ucfirst($rowGallery['gallery_title']);
                        $gallery_img = "./images/gallery/" . $rowGallery['gallery_img'];
                    ?>
                        <div class="col-md-4  mb-2">
                            <div class="card ">
                                <img src="<?php echo $gallery_img; ?>" class="card-img-top"  alt="<?php echo $gallery_title; ?>" data-toggle="modal" data-target="#imageModal<?php echo $gallery_id; ?>">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $gallery_title; ?></h5>
                                </div>
                            </div>
                        </div>
                        <!-- Image Modal -->
                        <div class="modal fade" id="imageModal<?php echo $gallery_id; ?>" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-centered">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="imageModalLabel"><?php echo $gallery_title; ?></h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <img src="<?php echo $gallery_img; ?>" class="img-fluid" alt="<?php echo $gallery_title; ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Image Modal -->
                    <?php } ?>
                </div>
            </div>
        </div>
    </div>


    <div class="row bg-dark mt-2">
        <?php include('inc/footer.php') ?>
    </div>
</div>

</body>

</html>
