<?php
session_start();
require_once('inc/db.php'); // Include database connection file
// Check if the session variable is not set
if(!isset($_SESSION['user_name'])){
    // Redirect user to the login page
    header('location: student_login.php');
    exit(); // Terminate script execution after redirection
}
// Check if student_id is provided
if(isset($_GET['student_id'])) {
    $studentId = $_GET['student_id'];

    // Fetch student details from the database based on the provided ID
    $query = "SELECT * FROM successfull_students WHERE student_id = $studentId";
    $result = mysqli_query($con, $query);

    // Check if there are any errors in the query
    if (!$result) {
        die("Query failed: " . mysqli_error($con));
    }

    // Check if student exists
    if(mysqli_num_rows($result) > 0) {
        // Fetch student details
        $row = mysqli_fetch_assoc($result);
?>
        <!-- Display student details -->
        <div class="card">
            <img src="<?php echo $row['suc_sdt_image']; ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?php echo $row['suc_sdt_name']; ?></h5>
                <p class="card-text">Class: <?php echo $row['suc_sdt_class']; ?></p>
                <p class="card-text">Batch: <?php echo $row['suc_sdt_batch']; ?></p>
                <!-- Add more details here if needed -->
            </div>
        </div>
<?php
    } else {
        echo "Student not found";
    }

    // Free result set
    mysqli_free_result($result);
} else {
    echo "Student ID not provided";
}
?>
