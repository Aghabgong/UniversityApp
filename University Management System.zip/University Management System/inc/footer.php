<div class="col-md-3 text-white bg-success text-center">
    <h2 >GREEN HILLS ACADEMY COMPLEX</h2><hr>
    <p class="">© 2024<a href="index.php"class="text-danger">G.H.A.C</a>, All rights Reserved.</p>
</div>

<div class="col-md-3 text-danger bg-success ">
    <h3 class=" text-white">Quick Menu</h3><hr>
    <ul>
        <li>
            <a href="#" class="text-danger">Privacy Policy</a>
        </li>
        <li>
            <a href="#"class="text-danger">Terms & Conditions</a>
        </li>
        <li>
            <a href="#"class="text-danger">Disclaimer</a>
        </li>
        <li>
            <a href="contact-us.php"class="text-danger">Contact Us</a>
        </li>
    </ul>
</div>

<div class="col-md-3 bg-success  text-center">
    <h3 class=" text-white">No Off Visitors</h3>
    <h4 class=" text-white">Designed & Developed By</h4>
    <a class="btn btn-danger btn-block" href="https://web.facebook.com/jude.christar.9">AGHABGONG JUDE</a>
</div>

<div class="col-md-3 bg-success  text-white text-center">
    <h3>Address</h3>
    <address>
        GREEN HILLS ACADEMY COMPLEX<br>
        DAMAS - YAOUNDE<br>
        Opposit MAISON MAMAS<br>
        Contact : +237650702580<br>
     </address>
</div>



