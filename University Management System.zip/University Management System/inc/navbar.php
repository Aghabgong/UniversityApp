<nav class="navbar navbar-expand-lg navbar-light bg-success ">
  <div class="container-fluid">
    <a class="navbar-brand text-light" href="index.php">Green Hills Academy Complex</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link active text-light" href="index.php"><i class="fa fa-home"></i>Home</a>
        </li>
        
          <li class="nav-item">
          <a class="nav-link text-light" href="students.php"><i class="fa fa-user"></i>Students</a>
        </li>
        <li class="nav-item dropdown dropdown-right">
          <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="fa fa-graduation"></i>Other Info
          </a>
          
           <div class="dropdown-menu " aria-labelledby="navbarDropdown">
            <a class="dropdown-item" href="download.php">Download.php</a>
            <a class="dropdown-item" href="result.php">Results</a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="edu-facilities.php">Educational Facilities</a>
               <a class="dropdown-item" href="students-corner.php">Student's Corner</a>
               <a class="dropdown-item" href="review.php">Write a Review</a>
               <a class="dropdown-item" href="register_for_exam.php">Exam Registration</a>
               <a class="dropdown-item" href="time_table.php">Time Table</a>
               <a class="dropdown-item" href="about-us.php"><i class="fa fa-laptop"></i>About us</a>
          </div>
        </li>
          
        <li class="nav-item">
          <a class="nav-link text-white" href="gallery.php" tabindex="-1"><i class="fa fa-photo"></i>Gallery</a>
        </li>
          <li class="nav-item">
          <a class="nav-link text-light" href="contact-us.php"><i class="fa fa-envelope"></i>Contact us</a>
        </li>
      </ul>
        
     <ul class="navbar-nav ml-auto">
         
         <?php
         // Check if the logout form is submitted
if(isset($_POST['logout'])) {
    // Destroy the session
    session_destroy();
    // Redirect to the index page or any desired page after logout
    header('Location: index.php');
    exit();
}


// Check if any user is logged in
if(isset($_SESSION['student_name']) || isset($_SESSION['leg_name']) || isset($_SESSION['admin_name'])) {
    // If logged in, show welcome message and logout button
    echo '<li class="nav-item dropdown dropdown-left">
            <span class="navbar-text text-light me-2">Welcome ';
    if(isset($_SESSION['student_name'])) {
        echo $_SESSION['student_name'];
    } elseif(isset($_SESSION['leg_name'])) {
        echo $_SESSION['leg_name'];
    } elseif(isset($_SESSION['admin_name'])) {
        echo $_SESSION['admin_name'];
    }
    echo '</span>
            <form method="post" action="logout.php">
                <button class="btn btn-link text-light" type="submit" name="logout"><i class="fa fa-sign-out"></i>Logout</button>
            </form>
          </li>';
} else {
    // If not logged in, show login dropdown menu
    echo '<li class="nav-item dropdown dropdown-left">
            <a class="nav-link dropdown-toggle text-light" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa fa-cog"></i>
            </a>
            <div class="dropdown-menu dropdown-left" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="admin/login.php">Admin Login</a>
                <a class="dropdown-item" href="student_login.php">Student Login</a>
                <a class="dropdown-item" href="lecturers/Login.php">Lecturers Login</a>
            </div>
        </li>';
}
?>

          
        
         <li class="nav-item">
            <a class="nav-link text-light" href="#"><i class="fa fa-facebook"></i></a>
        </li>
         <li class="nav-item">
            <a class="nav-link text-light" href="#"><i class="fa fa-youtube"></i></a>
        </li>
        
        </ul>
    </div>
      </nav>
