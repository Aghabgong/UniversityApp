<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);


    require_once('inc/top.php');
    require_once('inc/db.php');
?> 
<div class="">
                    <img src="images/logo.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
<div class="container mt-5">
    <h1 class="text-center text-success mb-4">Announcements</h1>
    <table class="table">
        <thead class="thead-dark">
            <tr>
                <th scope="col">Title</th>
                <th scope="col">Date</th>
                <th scope="col">Content</th>
            </tr>
        </thead>
        <tbody>
            <?php
               

                // Query to retrieve announcement data
                $sql = "SELECT title, date, content FROM announcements";
                $result = $con->query($sql);

                // Display announcement data in table rows
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row["title"] . "</td>";
                        echo "<td>" . $row["date"] . "</td>";
                        echo "<td>" . $row["content"] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No announcements found</td></tr>";
                }

                // Close database connection
               
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
