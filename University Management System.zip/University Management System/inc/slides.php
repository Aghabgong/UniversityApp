

<html>

<div id="carouselExampleControls"  class="carousel slide" data-ride="carousel" >
    <div class="carousel-inner  ">
        <?php
        // Directory where images are stored
        $image_directory = 'images/advert/';

        // Get list of files in the directory
        $files = scandir($image_directory);

        // Counter for adding active class to the first item
        $count = 0;

        // Iterate over the files
        foreach ($files as $file) {
            // Skip current and parent directories
            if ($file == '.' || $file == '..') {
                continue;
            }

            // Set active class for the first item
            $active_class = ($count == 0) ? 'active' : '';
            $count++;

            // Output carousel item with image
            echo '<div class="carousel-item ' . $active_class . '">';
            echo '<img style="width: 200px;" class="d-block w-100 " src="' . $image_directory . $file . '" data-toggle="modal" data-target="#imageModal' . $count . '" />';
            echo '</div>';
        }
        ?>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- Modal for displaying image details -->
<div class="modal fade" id="imageModal" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="imageModalLabel">Image Details</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <p>Additional information about the clicked image will be displayed here.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function(){
        $('.carousel').carousel();
    });
</script>
