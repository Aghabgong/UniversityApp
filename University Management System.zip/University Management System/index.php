<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

// Establish database connection
$con = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle form submission
if (isset($_POST['submit_review'])) {
    // Retrieve form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $rating = $_POST['rating'];
    $review_msg = $_POST['review'];
    $review_date = date("Y-m-d H:i:s"); // Current date and time

    // Image upload
    $target_dir = "images/"; // Directory where images will be stored
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false) {
        // File is an image
        $uploadOk = 1;
    } else {
        echo "<script>alert('File is not an image.')</script>";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["image"]["size"] > 500000) {
        echo "<script>alert('Sorry, your file is too large.')</script>";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif") {
        echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.')</script>";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "<script>alert('Sorry, your file was not uploaded.')</script>";
        // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // Image uploaded successfully
            // Insert review data into database
            $insert_review_query = "INSERT INTO review (review_name, review_email, review_rating, review_msg, review_date, review_img) 
                                    VALUES ('$name', '$email', '$rating', '$review_msg', '$review_date', '$target_file')";
            $insert_review_result = mysqli_query($con, $insert_review_query);

            if ($insert_review_result) {
                // Review inserted successfully
                echo "<script>alert('Review submitted successfully')</script>";
            } else {
                // Error inserting review
                echo "<script>alert('Failed to submit review')</script>";
            }
        } else {
            echo "<script>alert('Sorry, there was an error uploading your file.')</script>";
        }
    }
}

// Fetch name and review messages from the database
$reviews_query = "SELECT review_name, review_msg FROM review ORDER BY review_date DESC";
$reviews_result = mysqli_query($con, $reviews_query);

// Fetch categories and their fees
$categories_query = "SELECT cat_name, cat_fee FROM category";
$categories_result = mysqli_query($con, $categories_query);
?>
<div class="container-fluid p-0">
    <div class="row">
        <div class="text-center col-lg-12 mt-2">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-2">
        
        <div class="col-md-12">
            <div class="row p-2 text-center">
                <div class="col-md-12">
                    <?php include('inc/slide2.php'); ?>
                </div>
            </div>
        </div>
    </div>
    <div class="row mt-2">
        <div class="col-md-9">
            <h2 class="bg-success text-white text-center">Welcome to G.H.A.C</h2>
            <h2 class="text-justify"><b class="text-success">Green Hills Academy Complex</b> -- Solid Foundation, Discipline and Success --</h2>
            <hr>
            <div class="row">
                <div class="col-sm-12">
                    <h1>Reviews</h1>
                    <?php
                        // Display name and review messages
                        while($row = mysqli_fetch_assoc($reviews_result)) {
                            echo "<p><strong>Name:</strong> " . $row['review_name'] . "<br>";
                            echo "<strong>Message:</strong> " . $row['review_msg'] . "</p><br>";
                        }
                    ?>
                </div>
                <hr>
            </div>
            <h2 class="text-white bg-dark text-center">OUR FACULTIES</h2>
            <div class="row">
                <div class="col-md-12">
                    <table class="table table-border">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Department</th>
                                <th>Fees</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            // Display categories and their fees with pagination
$faculty_per_page = 5; // Number of faculties per page
$current_page = isset($_GET['page']) ? $_GET['page'] : 1; // Current page number
$offset = ($current_page - 1) * $faculty_per_page; // Offset for query
$faculty_query = "SELECT cat_name, cat_fee FROM category LIMIT $faculty_per_page OFFSET $offset";
$faculty_result = mysqli_query($con, $faculty_query);


                            while ($row = mysqli_fetch_assoc($faculty_result)) {
                                echo "<tr>";
                                echo "<td>" . $row['cat_name'] . "</td>";
                                echo "<td>" . $row['cat_fee'] . "</td>";
                                echo "</tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                    <!-- Pagination for faculties -->
                    <nav aria-label="Faculty Pagination">
                        <ul class="pagination justify-content-center">
                            <?php
                            // Calculate total pages
                            $total_faculty_query = "SELECT COUNT(*) AS total FROM category";
                            $total_faculty_result = mysqli_query($con, $total_faculty_query);
                            $total_faculty_count = mysqli_fetch_assoc($total_faculty_result)['total'];
                            $total_pages = ceil($total_faculty_count / $faculty_per_page);

                            // Generate pagination links
                            for ($i = 1; $i <= $total_pages; $i++) {
                                echo "<li class='page-item " . ($current_page == $i ? 'active' : '') . "'><a class='page-link' href='?page=$i'>$i</a></li>";
                            }
                            ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-success">
                <div class="card-body">
                    <h3 class="card-title text-center">G.H.A.C</h3>
                </div>
            </div>
            <img src="images/logo.jpg" class="img-fluid"/>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row bg-dark mt-2">
            <?php include('inc/footer.php'); ?>
        </div>
    </div>
</div>
</body>
</html>
