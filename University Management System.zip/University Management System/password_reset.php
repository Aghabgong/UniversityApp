<?php
ob_start();
session_start();
require_once('inc/db.php');

if(isset($_POST['submit'])){
    $email = mysqli_real_escape_string($con, $_POST['email']);
    
    // Check if the email exists in the database
    $check_email_query = "SELECT * FROM student_registration WHERE email = '$email'";
    $check_email_result = mysqli_query($con, $check_email_query);
    
    if($check_email_result && mysqli_num_rows($check_email_result) > 0){
        // Generate a unique token for password reset
        $token = bin2hex(random_bytes(16));
        
        // Store the token in the database along with the email
        $update_token_query = "UPDATE student_registration SET reset_token = '$token' WHERE email = '$email'";
        $update_token_result = mysqli_query($con, $update_token_query);
        
        if($update_token_result){
            // Send password reset link to the user's email
            $reset_link = "http://example.com/reset_password.php?email=$email&token=$token";
            // Send the reset link via email or display it on the page
            echo "Password reset link sent to your email. Please check your inbox.";
            
            // Additional code to send the email containing the reset link
            // Use PHP's mail function or a library like PHPMailer to send the email
        } else {
            // Handle database error
            echo "Error updating reset token.";
        }
    } else {
        // Email does not exist in the database
        echo "Email not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .container {
            margin-top: 100px;
        }
        h2 {
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .btn-primary {
            width: 100%;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>
        <form method="post">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <button type="submit" class="btn btn-primary" name="submit">Reset Password</button>
        </form>
    </div>
    <div class="container mt-3">
        <a href="index.php" class="btn btn-secondary">Back to Homepage</a>
    </div>
</body>
</html>
