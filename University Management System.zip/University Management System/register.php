<?php
ob_start();
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Check if exam_id is set in the URL
if(isset($_GET['exam_id'])) {
    $exam_id = $_GET['exam_id'];

    // Fetch exam information from the database
    $stmt_exam = $con->prepare("SELECT * FROM exams WHERE exam_id = ?");
    $stmt_exam->bind_param("i", $exam_id);
    $stmt_exam->execute();
    $result_exam = $stmt_exam->get_result();
    $exam_data = $result_exam->fetch_assoc();
    $stmt_exam->close();

    // Handle registration form submission
    if(isset($_POST['submit'])) {
        // Fetch student data from the form
        $name = $_POST['name'];
        $email = $_POST['email'];
        $category = $_POST['category'];
        $date = date("Y-m-d"); // Assuming registration date is current date
        
        // Prepare and bind statement to insert data into the database
        $stmt = $con->prepare("INSERT INTO register (student_name, cat_name, course_name, date, exam_id) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $name, $category, $exam_data['course_name'], $date, $exam_id);

        // Execute the statement
        $stmt->execute();

        // Close statement
        $stmt->close();
        
        // Redirect back to the exam list
        header("Location: register_for_exam.php");
        exit();
    }
} else {
    // Redirect to the exam list if exam_id is not set
    header("Location: register_for_exam.php");
    exit();
}

// Fetch categories from the database
$sql = "SELECT * FROM category";
$stmt_category = $con->prepare($sql);
$stmt_category->execute();
$result = $stmt_category->get_result();
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    
    <div class="container">
        <h2 class="mt-4">Exam Registration</h2>
        <div class="row">
            <div class="col-md-6">
                <h4>Exam Information</h4>
                <p><strong>Exam Name:</strong> <?php echo $exam_data['examName']; ?></p>
                <p><strong>Exam Date:</strong> <?php echo $exam_data['exam_date']; ?></p>
                <p><strong>Time:</strong> <?php echo $exam_data['time']; ?></p>
                <p><strong>Course Name:</strong> <?php echo $exam_data['course_name']; ?></p>
                <p><strong>Total Marks:</strong> <?php echo $exam_data['totalMarks']; ?></p>
            </div>
            <div class="col-md-6">
                <h4>Registration Form</h4>
                <form method="post">
                    <div class="form-group">
                        <label for="name">Name:</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="category">Department:</label>
                        <select class="form-control" id="category" name="category" required>
                            <option value="">Select Category</option>
                            <?php
                            if ($result->num_rows > 0) {
                                while($row = $result->fetch_assoc()) {
                                    echo "<option value='".$row['cat_name']."'>".$row['cat_name']."</option>";
                                }
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit" name="submit" class="btn btn-success">Register</button>
                </form>
            </div>
        </div>
    </div>
</div>
</body>
</html>
