<?php
ob_start();
session_start();
require_once('inc/top.php');
require_once('inc/db.php');

// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['student_name'])) {
    header('Location: student_login.php');
    exit();
}

// Fetch exams from the database
$sql = "SELECT * FROM exams";
$result = $con->query($sql);
?>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    
   <div class="container">
        <h2 class="mt-4">Exam Registration</h2>
        <table class="table mt-4">
            <thead class="thead-dark">
                <tr>
                    <th>Exam Name</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Course</th>
                    <th>Category</th>
                    <th>Total Marks</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>".$row['examName']."</td>";
                        echo "<td>".$row['exam_date']."</td>";
                        echo "<td>".$row['time']."</td>";
                        echo "<td>".$row['course_name']."</td>";
                        echo "<td>".$row['cat_name']."</td>";
                        echo "<td>".$row['totalMarks']."</td>";
                        echo "<td><a href='register.php?exam_id=".$row['exam_id']."' class='btn btn-primary'>Register</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No exams found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
