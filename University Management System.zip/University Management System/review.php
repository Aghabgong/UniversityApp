<?php
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    ob_start();
    session_start();

// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['student_name'])) {
    header('Location: student_login.php');
    exit();
}

    require_once('inc/top.php');
    require_once('inc/db.php');
    require_once('inc/navbar.php');

    // Handle form submission
    if(isset($_POST['submit_review'])) {
        // Retrieve form data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $rating = $_POST['rating'];
        $review_msg = $_POST['review'];
        $review_date = date("Y-m-d H:i:s"); // Current date and time

        // Validate email address
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo "<script>alert('Please enter a valid email address.')</script>";
            exit(); // Terminate script execution
        }

        // Image upload
        $target_dir = "images/"; // Directory where images will be stored
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        // Check if image file is a actual image or fake image
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check !== false) {
            // File is an image
            $uploadOk = 1;
        } else {
            echo "<script>alert('File is not an image.')</script>";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["image"]["size"] > 500000) {
            echo "<script>alert('Sorry, your file is too large.')</script>";
            $uploadOk = 0;
        }

        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "<script>alert('Sorry, only JPG, JPEG, PNG & GIF files are allowed.')</script>";
            $uploadOk = 0;
        }

        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "<script>alert('Sorry, your file was not uploaded.')</script>";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                // Image uploaded successfully
                // Insert review data into database
                $insert_review_query = "INSERT INTO review (review_name, review_email, review_rating, review_msg, review_date, review_img) 
                                        VALUES ('$name', '$email', '$rating', '$review_msg', '$review_date', '$target_file')";
                $insert_review_result = mysqli_query($con, $insert_review_query);

                if($insert_review_result) {
                    // Review inserted successfully
                    echo "<script>alert('Review submitted successfully')</script>";
                    echo "<script>window.open('index.php','_self')</script>";
                } else {
                    // Error inserting review
                    echo "<script>alert('Failed to submit review')</script>";
                }
            } else {
                echo "<script>alert('Sorry, there was an error uploading your file.')</script>";
            }
        }
    }
?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <h2 class="text-center mb-4">Submit a Review</h2>
            <form action="index.php" method="POST" enctype="multipart/form-data" id="reviewForm">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="rating">Rating:</label>
                    <select class="form-control" id="rating" name="rating" required>
                        <option value="">Select Rating</option>
                        <option value="5">5 Stars</option>
                        <option value="4">4 Stars</option>
                        <option value="3">3 Stars</option>
                        <option value="2">2 Stars</option>
                        <option value="1">1 Star</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="review">Review:</label>
                    <textarea class="form-control" id="review" name="review" rows="5" required></textarea>
                </div>
                <div class="form-group mt-2">
                    <label for="image">Upload Image:</label>
                    <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
                </div>
                <button type="submit" class="btn btn-success mt-2" name="submit_review">Submit Review</button>
            </form>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row bg-dark mt-2">
        <?php include('inc/footer.php'); ?>
    </div>
</div>
</body>
</html>

<script>
    // Validate email address
    function isValidEmail(email) {
        var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }

    // Form submission handler
    document.getElementById("reviewForm").addEventListener("submit", function(event) {
        var email = document.getElementById("email").value;

        // Validate email
        if (!isValidEmail(email)) {
            alert("Please enter a valid email address.");
            event.preventDefault(); // Prevent form submission
        }
    });
</script>
