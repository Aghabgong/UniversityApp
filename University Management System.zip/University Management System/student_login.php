<?php
ob_start();
session_start();

require_once('inc/top.php');
require_once('inc/db.php');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle login form submission
if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Retrieve user data from the database
    $get_user_query = "SELECT * FROM student_registration WHERE email = '$email'";
    echo "SQL Query: " . $get_user_query; // Debugging SQL query
    $run_user_query = mysqli_query($con, $get_user_query);

    if ($run_user_query) {
        $user_data = mysqli_fetch_assoc($run_user_query);

        if ($user_data) {
            // Debugging the stored password
            echo "Stored Password Hash: " . $user_data['password'] . "<br>";

            // Verify the password against the hashed password in the database
            if (password_verify($password, $user_data['password'])) {
                echo "Password verification passed<br>"; // Debugging password verification
                // Password is correct, log the user in
                $_SESSION['student_name'] = $email;
                header('Location: students.php');
                exit(); // Stop further execution
            } else {
                echo "<script>alert('Email or Password not correct. You can reset your password.')</script>";
                echo "Password verification failed<br>"; // Debugging password verification
            }
        } else {
            echo "<script>alert('Email or Password not correct. You can reset your password.')</script>";
            echo "No user found with this email<br>"; // Debugging user lookup
        }
    } else {
        echo "<script>alert('Error executing SQL query')</script>";
        echo "SQL query execution failed<br>"; // Debugging SQL execution
    }
}

// Uncomment these lines to debug the session variable
// echo "<pre>";
// var_dump($_SESSION);
// echo "</pre>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Login</title>
</head>
<body>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="container-fluid row mt-1">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center text-white bg-success">Student Login</h2><hr>
            </div>
            <form action="" method="post">
                <div class="form-group row mt-2 p-20">
                    <label class="col-sm-2 col-form-label text-danger">
                        Email
                    </label>
                    <div class="col-sm-10">
                        <input type="email" class="form-control" placeholder="Enter email" name="email" required/>
                    </div>
                </div>
                <div class="form-group mt-2 row">
                    <label class="col-sm-2 col-form-label text-danger">
                        Password
                    </label>
                    <div class="col-sm-10">
                        <input type="password" class="form-control" placeholder="Enter password" name="password" required/>
                        <div class="form-group mt-2 row">
                            <div class="col-sm-10">
                                <button class="btn btn-outline-success btn-block mt-2" type="submit" name="submit">Login</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <p class="text-center">Don't have an account? <a href="student_registration.php">Sign up here</a></p>
        </div>
    </div>
</div>
</body>
</html>
<div class="row bg-dark mt-2"><?php include('inc/footer.php') ?></div>
