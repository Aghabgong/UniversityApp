<?php

session_start();


require_once('inc/top.php');
require_once('inc/db.php');

// Check if 'id' parameter is set in the URL
if(isset($_GET['id'])){
    $student_id = $_GET['id'];
    
    // Fetch student details based on student ID
    $student_query = "SELECT * FROM student WHERE id = '$student_id'"; // Assuming 'id' is the column name for student ID
    $student_result = mysqli_query($con, $student_query);

    if (!$student_result) {
        // Query failed, handle the error
        echo "Error: " . mysqli_error($con);
    } else {
        // Query succeeded, fetch student data
        $student_data = mysqli_fetch_assoc($student_result);

        if (!$student_data) {
            // No student data found with the provided ID, handle accordingly
            header('location: error.php');
            exit();
        }
    }
}

?>
<style>
.card-img-top{
    width: 100%;
    height: 300px;
    object-fit: contain;
}
</style>
<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">   
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-6">
                    <img src="images/logo.jpg" class="" width="70px"/><hr>
                    <div class="card">
                        <img src="<?php echo isset($student_data['image']) ? 'images/advert/' . $student_data['image'] : ''; ?>" class="card-img-top" alt="Student Image">
                      
                     
                   
                    </div>   
                         
                </div>
                <div class="col-md-6"><hr>
                             <div class="card-body">
                            <h5 class="card-title text-center"><?php echo isset($student_data['student_name']) ? $student_data['student_name'] : ''; ?></h5>
                            <p class="card-text">Address: <?php echo isset($student_data['address']) ? $student_data['address'] : ''; ?></p>
                            <p class="card-text">Category: <?php echo isset($student_data['cat_name']) ? $student_data['cat_name'] : ''; ?></p> <!-- Replace 'class' with 'cat_name' -->
                            <p class="card-text">Gender: <?php echo isset($student_data['gender']) ? $student_data['gender'] : ''; ?></p>
                            <p class="card-text">Mobile: <?php echo isset($student_data['mobile']) ? $student_data['mobile'] : ''; ?></p>
                            <p class="card-text">Email: <?php echo isset($student_data['email']) ? $student_data['email'] : ''; ?></p>
                            <p class="card-text">Date of Birth: <?php echo isset($student_data['date_of_birth']) ? $student_data['date_of_birth'] : ''; ?></p>
                             <div class="row">
                    <div class="col-md-8">
                        <h2 class="text-center text-white bg-secondary">Marks Allocation</h2><hr>
                        <table class="table table-bordered table-condensed" id="table2excel">
                            <thead class="bg-dark text-white">
                                <tr>
                                    <th>Date</th>
                                    <th>Subject</th>
                                    <th>Total Marks</th>
                                    <th>Optain Marks</th>
                                </tr>
                            </thead>
                        <tbody>
                            <?php 
                            if(isset($_GET['id'])) {
    $user_id = $_GET['id'];
} else {
    // Handle the case when 'id' parameter is not set
    // For example, redirect the user, show an error message, or set a default value
    // Here, we'll set a default value of 0
    $user_id = 0;
}

                                $result = "SELECT * FROM result WHERE student_id = '$user_id'";
                            $run_result = mysqli_query($con,$result);
                            
                            $ia = 0;
                            
                            while($row_result = mysqli_fetch_assoc($run_result)){
                                $date = $row_result['date'];
                                $subject = $row_result['subject'];
                                $totalMarks = $row_result['totalMarks'];
                                $obtainedMarks = $row_result['obtainedMarks'];
                            
                            
                            
                            ?>
                            <tr>
                                <td><?php echo $date; ?></td>
                            <td><?php echo $subject; ?></td>
                            <td><?php echo $totalMarks; ?></td>
                            <td><?php echo $obtainedMarks; ?></td>
                            </tr>
                            <?php };?>
                            </tbody>
                        </table><hr>
                     </div>
                     <div class="col-md-4">
                     <h2 class="text-center bg-success text-white">Attendance Details</h2><hr>
                         <div class="row ">
                             <?php 
                                $present = "SELECT * from attendance Where student_id = '$user_id' && attendance = 'Present'";
                             $run_present = mysqli_query($con,$present);
                             $row_present = mysqli_num_rows($run_present);
                             
                              $absent = "SELECT * from attendance Where student_id = '$user_id' && attendance = 'Absent'";
                             $run_absent = mysqli_query($con,$absent);
                             $row_absent = mysqli_num_rows($run_absent);
                             
                             
                             ?>
                            <div class="col-md-12">
                             <button type="button" class="btn btn-info btn-block">Present Days<span class="badge badge-light"><?php echo $row_present;?></span></button>
                             </div>
                             <div class="col-md-12 mt-2">
                             <button type="button" class="btn btn-danger btn-block">Absent Days<span class="badge badge-light"><?php echo $row_absent;?></span></button>
                             </div>
                         </div>
                         
                         </div>
                 </div>
                        </div>
                        </div>
            </div>    
        </div>
    </div>
    <div class="row bg-dark mt-2"><?php include('inc/footer.php')?></div>
</div>
