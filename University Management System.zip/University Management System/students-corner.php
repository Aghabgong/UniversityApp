<?php
include('inc/top.php');
           
// Start session
            session_start();

// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['student_name'])) {
    header('Location: student_login.php');
    exit();
}

?>
 <?php include('inc/navbar.php'); ?>
           

<div class="container-fluid p-0">
    <div class="row">
        <div class="col-lg-12 mt-2">

   
        </div>
    </div>
    
    <div class="row mt-2" >
        <div class="col-md-9">
       <h2 class="text-center bg-secondary text-white">Students Corner</h2><hr>
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-danger">Rules For Conduct :</h4>
                    <ol>
                        <li>Students be a gentleman.</li>
                         <li>Students must behave in an obedient, humble manner with professors and office staff. Any act of arrogance will be dealt with firmly.</li>
                         <li>Students must Carry their Identity card everyday.</li>
                         <li>Loitering in the corridors, peeping in the classes, calling someone from the class, etc, will be considered misbehavior and is liable for punishment.</li>
                         <li>Students must obey all the rules while in their class, office, library and laboratory.</li>
                         <li>Damage to the School property will be considered an offense</li>
                        <li>Students should park their vehicles only in the sheds meant for parking, otherwise they will be fined.</li>
                        <li>Outsiders will not be allowed to enter classrooms, laboratories library, office and entire premises without pre-permission.</li>
                    </ol><hr>
                    <p>The Director has full authority to punish and even cancel the admission of the students and also take legal action for their behavior in the college premises.</p>
                </div>
            </div>
            
        </div>
        <div class="col-md-3">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <h3 class="card-title text-center">Director</h3>
                </div>
            </div>
            <img src="images/students%20(1).jpg" class="img-fluid"/>
        </div>
    </div>
    
    <div class="container-fluid">
        <div class="row bg-dark mt-2">
        <?php include('inc/footer.php'); ?>
    </div>
    </div>
</div>

</body>
</html>