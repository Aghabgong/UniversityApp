<?php
ob_start();
session_start();
// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['student_name'])) {
    header('Location: student_login.php');
    exit();
}

require_once('inc/top.php');
require_once('inc/db.php');

// Fetch all unique categories
$query = "SELECT DISTINCT cat_name FROM student";
$categories_result = mysqli_query($con, $query);
$categories = [];
while ($row = mysqli_fetch_assoc($categories_result)) {
    $categories[] = $row['cat_name'];
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['category'])) {
    $selected_category = $_POST['category'];
    // Fetch students based on the selected category
    $query = "SELECT * FROM student WHERE cat_name = '$selected_category'";
} else {
    // If no category is selected, fetch all students
    $query = "SELECT * FROM student";
}
$result = mysqli_query($con, $query);
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php') ?>
        </div>
    </div>
    <div class="row mt-1">
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <img src="images/logo.jpg" class="img-fluid" width="70px" />
                    <hr>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">View All Students</h2>
                    <!-- Filter form -->
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="category">Filter Department:</label>
                            <select class="form-control" id="category" name="category">
                                <option value="">All</option>
                                <?php foreach ($categories as $cat) { ?>
                                    <option value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-success">Apply Filter</button>
                    </form>
                    <hr>
                    <table class="table table-border" id="table2excel">
                        <thead class="bg-dark text-white">
                            <tr>
                                <th>Sr No</th>
                                <th>Student Name</th>
                                <th>Category</th>
                                <th>Image</th>
                                <th><a class="fa fa-eye"></a></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 0;
                            while ($row = mysqli_fetch_assoc($result)) {
                                $id = $row['id'];
                                $name = $row['name'];
                                $category = $row['cat_name'];
                                $image = $row['image'];
                                $i++;
                            ?>
                                <tr>
                                    <td><?php echo $i ?></td>
                                    <td><?php echo ucfirst($name); ?></td>
                                    <td><?php echo $category; ?></td>
                                    <td><img class="img-fluid" src="images/advert/<?php echo $image; ?>" width="50px" /></td>
                                    <td><a class="btn btn-success" href="student_profile.php?id=<?php echo $id; ?>"><i class="fa fa-eye"></i></a></td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="row bg-dark mt-2">
        <?php include('inc/footer.php') ?>
    </div>
</div>

</body>

</html>
