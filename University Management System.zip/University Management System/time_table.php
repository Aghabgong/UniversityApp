<?php
// Start session and include necessary files
session_start();
require_once('inc/top.php');
require_once('inc/db.php');
// Check if the user is not logged in, then redirect to the login page
if (!isset($_SESSION['student_name'])) {
    header('Location: student_login.php');
    exit();
}

// Check database connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Define days of the week
$days = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday');

// Fetch categories from the database
$categoriesQuery = "SELECT * FROM category";
$categoriesResult = mysqli_query($con, $categoriesQuery);
if (!$categoriesResult) {
    die('Error fetching categories: ' . mysqli_error($con));
}
$categories = array();
while ($categoryRow = mysqli_fetch_assoc($categoriesResult)) {
    $categories[$categoryRow['cat_id']] = $categoryRow['cat_name'];
}

// Fetch all records from the teacher_assignments table along with course and teacher details
$assignmentsQuery = "SELECT ta.day_of_week, t.teacher_name, c.course_name, ta.cat_id
                     FROM teacher_assignments ta
                     INNER JOIN teachers t ON ta.teacherid = t.teacherid
                     INNER JOIN courses c ON ta.course_id = c.course_id";
$assignmentsResult = mysqli_query($con, $assignmentsQuery);
if (!$assignmentsResult) {
    die('Error fetching assignments: ' . mysqli_error($con));
}

// Initialize an array to store timetable data
$timetable = array();
// Initialize timetable structure
foreach ($categories as $categoryId => $categoryName) {
    $timetable[$categoryName] = array_fill_keys($days, array());
}

// Loop through each assignment record
while ($row = mysqli_fetch_assoc($assignmentsResult)) {
    $dayOfWeek = $row['day_of_week'];
    $teacherName = $row['teacher_name'];
    $courseName = $row['course_name'];
    $categoryId = $row['cat_id'];
    $categoryName = $categories[$categoryId];
    // Add the teacher to the respective category for the given day
    $timetable[$categoryName][$dayOfWeek][] = array('teacher_name' => $teacherName, 'course_name' => $courseName);
}
?>

<div class="container-fluid">
    <div class="row mt-2">
        <div class="col-md-12">
            <?php include('inc/navbar.php'); ?>
        </div>
    </div>
    <div class="row mt-1">
       
        <div class="col-md-12">
            <div class="row">
                <div class="col-md-12">
                    <h2 class="text-center text-white bg-success">Timetable for Each Category</h2>
                    <hr>
                    <?php foreach ($timetable as $categoryName => $assignmentsByDay): ?>
                        <h3><?php echo $categoryName; ?></h3>
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Day</th>
                                    <th>Assignments</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($assignmentsByDay as $day => $assignments): ?>
                                    <tr>
                                        <td><?php echo $day; ?></td>
                                        <td>
                                            <?php foreach ($assignments as $assignment): ?>
                                                <?php echo $assignment['teacher_name'] . ' - ' . $assignment['course_name'] . '<br>'; ?>
                                            <?php endforeach; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row bg-dark mt-2"><?php include('inc/footer.php'); ?></div>

</body>
</html>
